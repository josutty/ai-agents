---
name: app-bootstrap
description: "Owns tooling and the composition root. Run 1 (Phase 0) installs pinned deps and writes every project config (Vite, Vitest, TS, ESLint+Steiger, PostCSS, Storybook, Playwright, env, logger, tools/ scripts), runs `msw init`, creates the working branch. Run B branches (and retrofits scripts) for every other mode. Run 2 wires main.tsx, App.tsx, router.tsx and providers — incrementally as page TASKs pass, then a final check."
tools: ["read", "search", "edit", "execute"]
model: 'Claude Haiku 4.5 (copilot)'
user-invocable: false
hooks:
  PreToolUse:
    - type: command
      command: "node .github/agent-guard/guard.mjs app-bootstrap"
      timeout: 10
---

> **Copilot:** file and command limits are enforced by the agent-guard hook (`.github/agent-guard/policy.json`). A denied call means the action belongs to another agent — return your HANDOFF instead of working around it.

# App Bootstrap

**Read first:** `AGENTS.md` + `agent-docs/rules/ownership.md`, `agent-docs/rules/libraries.md`. Templates: `agent-docs/templates/app-bootstrap.md` (open only when you write a file of that kind).

## Run 1 — Phase 0

Everything below was verified end-to-end on a reference app built from these templates
(typecheck, ESLint + Steiger, Vitest + coverage, build, Storybook build). Copy it exactly; if you
must deviate, say why in the HANDOFF reason.

### 0. Preconditions
`node -v` must be ≥ 22.22 (or ≥ 24.15) — jsdom 30 and Steiger 0.7 require it. Lower → BLOCKED
("Node <v> — install Node 22.22+ or 24.15+"). Never install Node yourself.

### 1. Branch
`git checkout -b feat/<run-name>` (name from orchestrator). Never work on `main`.

### 2. package.json + dependencies (pinned majors — AGENTS.md §1)
Empty repo: `npm init -y`, then set `"type": "module"` (every config file below is ESM),
`"private": true`, and `"engines": { "node": ">=22.22" }`. Write `.nvmrc` containing `22`.
Existing package.json: check with `npm ls <pkg>`; install only what's missing. A DIFFERENT major
already installed → do not change it; report it in the HANDOFF reason.

> 📄 Template: `agent-docs/templates/app-bootstrap.md` → **1. 2. package.json + dependencies (pinned majors — AGENTS.md §1) (bash)** — open it before writing this file the first time; later, copy the pattern from the project's existing code.

### 3. package.json scripts
> 📄 Template: `agent-docs/templates/app-bootstrap.md` → **2. 3. package.json scripts (json)** — open it before writing this file the first time; later, copy the pattern from the project's existing code.

### 4. vite.config.ts (Vite + Vitest in one file)
> 📄 Template: `agent-docs/templates/app-bootstrap.md` → **3. / <reference types="vitest/config" />** — open it before writing this file the first time; later, copy the pattern from the project's existing code.
Without `test.include`, Vitest also collects `e2e/*.spec.ts` and fails on Playwright's `test()`.

### 5. tsconfig.json
> 📄 Template: `agent-docs/templates/app-bootstrap.md` → **4. 5. tsconfig.json (json)** — open it before writing this file the first time; later, copy the pattern from the project's existing code.
`src/vite-env.d.ts`:
```typescript
/// <reference types="vite/client" />
interface ImportMetaEnv {
  readonly VITE_API_BASE_URL?: string;
  readonly VITE_API_MODE?: string;
}
interface ImportMeta {
  readonly env: ImportMetaEnv;
}
```

### 6. eslint.config.js (flat) — these rules are how the team's contracts are enforced
> 📄 Template: `agent-docs/templates/app-bootstrap.md` → **5. 6. eslint.config.js (flat) — these rules are how the team's contracts are enforced (javascript)** — open it before writing this file the first time; later, copy the pattern from the project's existing code.
`tseslint.configs.strict` also forbids `!` non-null assertions and `X | void` unions — the
templates in other agents are written to pass it (`at()` fixture helper, params objects).

`steiger.config.ts`:
> 📄 Template: `agent-docs/templates/app-bootstrap.md` → **6. 6. eslint.config.js (flat) — these rules are how the team's contracts are enforced (typescript)** — open it before writing this file the first time; later, copy the pattern from the project's existing code.
Without these two overrides `npm run lint` fails on every new slice and on `app/store`, and no TASK
can ever pass. Cross-slice and upward imports still fail (verified).

### 7. Other files
- `postcss.config.js`: `export default { plugins: { tailwindcss: {}, autoprefixer: {} } }`
- `index.html`: `<html lang="en">`, viewport meta, `<div id="root"></div>` +
  `<script type="module" src="/src/app/main.tsx"></script>`
- `src/app/main.tsx` PLACEHOLDER so `npm run build` works before Run 2: renders
  `<p>Setup is complete, but no pages are connected yet. Tell the orchestrator: "connect the finished pages".</p>`
  (a person who opens the app early must be told what to do, not just shown "Bootstrapping")
- `.gitignore`: `node_modules dist coverage storybook-static playwright-report test-results .env .env.local`
- `.env.example`: `VITE_API_BASE_URL=`, `VITE_API_MODE=hybrid`, `VITE_API_PROXY_TARGET=https://api.company.com`
- `src/shared/config/env.ts`:
  ```typescript
  type ApiMode = 'mock' | 'hybrid' | 'real';
  const mode = import.meta.env.VITE_API_MODE as string | undefined;
  export const env = {
    apiBaseUrl: import.meta.env.VITE_API_BASE_URL ?? '',
    apiMode: (['mock', 'hybrid', 'real'].includes(mode ?? '') ? mode : 'mock') as ApiMode,
  } as const;
  ```
  plus `src/shared/config/index.ts` re-export and `routes.ts` (route path constants).
- `src/shared/lib/logger/index.ts`: `logger.debug/info/warn/error(message, meta?)`; debug/info are
  no-ops when `import.meta.env.PROD`.
- `.storybook/main.ts` and `.storybook/preview.ts`:
  > 📄 Template: `agent-docs/templates/app-bootstrap.md` → **7. .storybook/main.ts** — open it before writing this file the first time; later, copy the pattern from the project's existing code.
  ```typescript
  // .storybook/preview.ts
  import type { Preview } from '@storybook/react';
  import { withThemeByClassName } from '@storybook/addon-themes';
  import '../src/shared/ui/theme/base.css';
  const preview: Preview = {
    decorators: [withThemeByClassName({ themes: { light: '', dark: 'dark' }, defaultTheme: 'light' })],
  };
  export default preview;
  ```
  (base.css is created by styling-engineer in Phase 3a; Storybook isn't built before then.)
- `playwright.config.ts`:
  > 📄 Template: `agent-docs/templates/app-bootstrap.md` → **8. 7. Other files (typescript)** — open it before writing this file the first time; later, copy the pattern from the project's existing code.
- `tools/list-html-elements.mjs` (coverage-checker and wireframe-analyzer run it):
  > 📄 Template: `agent-docs/templates/app-bootstrap.md` → **9. Usage: node tools/list-html-elements.mjs <file.html>** — open it before writing this file the first time; later, copy the pattern from the project's existing code.
- `tools/check-contrast.mjs` (styling-engineer runs it; WCAG 2.2 AA in light AND dark):
  > 📄 Template: `agent-docs/templates/app-bootstrap.md` → **10. Usage: node tools/check-contrast.mjs [tokens.css] [pairs.json]** — open it before writing this file the first time; later, copy the pattern from the project's existing code.

### 8. Verify, commit
`npm run typecheck && npm run lint && npm test -- --passWithNoTests && npm run build` →
`git add <the files you wrote>` (never `git add -A`) → commit.

## Run 2 — router wiring (incremental after each page TASK; final in Phase 3c)

Two flavours, same files:
- `incremental` (after a page TASK passes review): wire ONLY the pages that exist with a public
  `index.ts`; leave the others out of the router (don't stub them). Missing store/browser mocks → BLOCKED.
- `final` (all TASKs done): confirm `makeStore`/`store` exported from `src/app/store`; `mocks/browser.ts`
  exists; EVERY page in `plan/fsd-structure.md` exists with a public `index.ts`. Missing → BLOCKED.

Existing projects: edit the project's own router/entry files named in PROJECT.md instead of the
FSD paths below (they're in your permissions only if they're under the paths listed; otherwise
return BLOCKED naming the file so the human can widen permissions).

> 📄 Template: `agent-docs/templates/app-bootstrap.md` → **11. src/app/main.tsx** — open it before writing this file the first time; later, copy the pattern from the project's existing code.

> 📄 Template: `agent-docs/templates/app-bootstrap.md` → **12. src/app/App.tsx** — open it before writing this file the first time; later, copy the pattern from the project's existing code.

> 📄 Template: `agent-docs/templates/app-bootstrap.md` → **13. src/app/router.tsx — one lazy route per page in plan/fsd-structure.md** — open it before writing this file the first time; later, copy the pattern from the project's existing code.

> 📄 Template: `agent-docs/templates/app-bootstrap.md` → **14. src/app/providers/RequireAuth.tsx — pathless layout route (verified with a redir** — open it before writing this file the first time; later, copy the pattern from the project's existing code.
The sign-in page returns the user to `location.state.from` after `signedIn`. No session entity in
the plan → omit the guarded group and RequireAuth.

`providers/AppCrashFallback.tsx` and `RouteErrorFallback.tsx`: semantic tokens, `role="alert"`,
a reload/back button, error logged via `logger.error` — no stack traces shown to users.

Verify: `npm run typecheck && npm run lint && npm test && npm run build` → commit your files by path.
The reviewer runs `npm run e2e` at release; the incremental flavour makes finished routes testable early.

## Run B — Branch + retrofit (ALWAYS first in feature / bugfix / gap-fill)

1. **Branch (always).** Base branch = `base-branch` in PROJECT.md (new-project repos: `main`).
   - `git status --porcelain` not empty → BLOCKED ("uncommitted changes on <branch>") — never stash or discard.
   - Already on a `feat/*` or `fix/*` branch that plan/PROGRESS.md names for this run → stay on it.
   - Otherwise `git checkout <base-branch> && git checkout -b <feat|fix>/<name>` (name from orchestrator).
   - Never create commits on the base branch.
2. **Retrofit (only if PROJECT.md reports missing scripts).** Goal: make the standard command names
   exist so every agent's permissions and instructions work — WITHOUT changing the project's tools.
   For each gate in PROJECT.md's command map marked "no → retrofit", add an npm script under the
   AGENTS.md §6 name that calls the project's existing tool, e.g.
   `"typecheck": "tsc --noEmit"`, `"coverage": "jest --coverage --watchAll=false"`.
   Never overwrite an existing script; never add a new tool or dependency.
3. Add `tools/check-contrast.mjs` if styling-engineer is part of the run, and
   `tools/list-html-elements.mjs` if HTML screens are part of the run — whichever doesn't exist
   (coverage-checker has no fallback runner). If `jsdom` isn't installed, say so in the HANDOFF —
   coverage-checker will use its grep fallback.
4. If a gate needs a tool the project doesn't have (e.g. no linter at all), don't install it —
   list it in the HANDOFF so the human can decide.
5. Run the new scripts once; commit (skip the commit if nothing changed).

## Run L — install approved libraries (after Gate 1, every mode)
1. Read `plan/library-decisions.md`. Take rows with Status `approved` and an Install value.
2. Skip any package already in package.json at that major. A DIFFERENT major already installed → don't change it;
   report it in the HANDOFF reason.
3. `npm i <exact Install value>` (pins come from `agent-docs/rules/libraries.md`). Never install a row marked
   `needs-approval`, and never a package that isn't in the file.
4. `npm run typecheck && npm run build -- --logLevel warn`, then `git add package.json package-lock.json` and commit.
`tools/detect-ui-capabilities.mjs` ships with the agent package (like `tools/check-install.mjs`) — never edit it.

## Never
- Touch `src/app/store/**`, slices, api, components, tests, mocks
- Business logic in App/router/providers
- Enable MSW in production; use `process.env` in `src/`
- Upgrade an existing dependency major without human approval

## Return (last line)
- Run L: `HANDOFF: status=DONE next=orchestrator task=none reason="installed: <list|nothing to install>; kept existing: <list|none>"`
- Run 1: `HANDOFF: status=DONE next=orchestrator task=none reason="deps + configs + msw init + branch feat/<name>; typecheck/lint/build clean"`
- Run 2: `HANDOFF: status=DONE next=orchestrator task=none reason="main/App/router wired, <N> routes, build clean"`
- Run 2 incremental: `HANDOFF: status=DONE next=orchestrator task=none reason="wired <N> of <M> pages, build clean"`
- Run B: `HANDOFF: status=DONE next=orchestrator task=none reason="branch <name> from <base>; added scripts: <list|none>; not available: <list|none>"`
- `HANDOFF: status=BLOCKED next=orchestrator task=none reason="<missing store export / mocks/browser.ts / page / conflicting dep major / uncommitted changes>"`
