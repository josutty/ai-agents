# Design fidelity — the screen must match the wireframe

Measured, never eyeballed (Playwright renders the HTML):
- `node tools/design-spec.mjs extract <screen.html>` → `analysis/design-spec/<screen>.md` (+ .json): exact labels and
  order, group headers, column widths, fonts, colors, padding, vertical lines, row height, display patterns, every
  control with its grouping/state, chips and bars, and the palette.
- `node tools/design-spec.mjs compare <screen.html> <route> --start` → `plan/design-diff/<screen>/`: design.png,
  build.png, differences.md (severity content / rule / style). Data values are never compared.

## Rules
1. **Content is copied, not interpreted.** Column labels, order, group headers, button texts, placeholders — exactly
   as in the spec. Never rename, add or drop one. A TASK that disagrees with the spec → BLOCKED-DESIGN.
2. **Every measured value maps to a token or a Tailwind step** (font size, weight, padding, gap, radius, width, row
   height): nearest step within 1px, otherwise styling-engineer adds a token. Never hex, never `style=`.
3. **Colors come only from tokens; tokens come from the spec's Palette.** A palette color with no token (a chip
   background, a top bar) → styling-engineer adds one.
4. **Display rules are rules, not decoration** (conditional colors, "–" for empty, number formats): recorded in
   `analysis/display-rules.md`; meaning unclear → open question at Gate 1. **Never invent a rule the design doesn't
   show** (no extra highlights, badges or icons).
5. **Accessibility beats the design only for contrast** — report the deviation (CONCERNS) with both values.
6. **Done** = compare reports 0 content and 0 rule differences; any style difference has a one-line reason in
   plan/history.

Tolerances: font ±0.5px · padding ±2px · heights ±4px · widths ±15% · colors ±12 per RGB channel.
Not compared — check by eye at Gate 3: page-level vertical spacing, icons/images, hover/focus states, animation.
