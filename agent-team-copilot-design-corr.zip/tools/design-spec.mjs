/* global document, getComputedStyle -- functions passed to page.evaluate run in the browser */
// Design fidelity tool (agent-docs/rules/design-fidelity.md). Renders in a real browser (Playwright).
//   node tools/design-spec.mjs extract <design.html> [--out analysis/design-spec]
//   node tools/design-spec.mjs compare <design.html> <url | /route> [--start] [--out plan/design-diff]
// `--start` runs the dev server in mock mode for the comparison. Browser: `npx playwright install chromium`
// (or set CHROMIUM_PATH). Exit code 1 when compare finds mismatches beyond tolerance.
import { chromium } from '@playwright/test';
import { mkdirSync, writeFileSync } from 'node:fs';
import { spawn } from 'node:child_process';
import { basename, resolve } from 'node:path';
import { pathToFileURL } from 'node:url';

const [cmd, a, b, ...rest] = process.argv.slice(2);
const flag = (n, d) => { const i = rest.indexOf(n); return i >= 0 ? rest[i + 1] : d; };
const VIEWPORT = { width: 1440, height: 900 };

async function open(browser, target) {
  const page = await browser.newPage({ viewport: VIEWPORT });
  await page.goto(/^https?:/.test(target) ? target : pathToFileURL(resolve(target)).href, { waitUntil: 'networkidle' });
  await page.waitForTimeout(300);
  return page;
}

// Runs inside the page: returns the spec of the first data table + controls + palette.
function readSpec() {
  const px = (v) => Math.round(parseFloat(v) * 10) / 10 || 0;
  const style = (el) => {
    const s = getComputedStyle(el);
    return { fontFamily: s.fontFamily.split(',')[0].replace(/["']/g, '').trim(), fontSize: px(s.fontSize), fontWeight: Number(s.fontWeight),
      color: s.color, background: s.backgroundColor, textAlign: s.textAlign, textTransform: s.textTransform,
      letterSpacing: s.letterSpacing === 'normal' ? 0 : px(s.letterSpacing), whiteSpace: s.whiteSpace,
      paddingX: px(s.paddingLeft), paddingY: px(s.paddingTop), borderRight: px(s.borderRightWidth) ? s.borderRightColor : 'none',
      borderRadius: px(s.borderTopLeftRadius), position: s.position };
  };
  const text = (el) => (el.innerText ?? el.textContent ?? '').replace(/\s+/g, ' ').trim();
  const out = { table: null, controls: [], decor: [], palette: {} };
  const table = document.querySelector('table');
  if (table) {
    const headRows = [...table.querySelectorAll('thead tr')];
    const leafRow = headRows[headRows.length - 1];
    const groupRow = headRows.length > 1 ? headRows[0] : null;
    const firstBody = table.querySelector('tbody tr');
    const bodyRows = [...table.querySelectorAll('tbody tr')];
    const leaves = [...leafRow.children].map((th, i) => {
      const cells = bodyRows.map((r) => r.children[i]).filter(Boolean);
      const cell = cells[0];
      const valueEl = cell && (cell.querySelector('input, span, a') && !cell.querySelector('input') ? cell.querySelector('span, a') : cell);
      const colors = [...new Set(cells.map((c) => getComputedStyle(c.querySelector('span:not(.was)') ?? c).color))];
      const input = cell?.querySelector('input');
      const secondary = cell && [...cell.querySelectorAll('span, div, small')].find((e) => e !== valueEl && text(e) && input);
      return {
        label: text(th), width: Math.round(th.getBoundingClientRect().width), header: style(th),
        body: cell ? style(cell) : null, value: valueEl && valueEl !== cell ? style(valueEl) : null,
        conditionalColors: colors.length > 1 ? colors : [],
        emptyShownAs: cells.map((c) => text(c)).find((t) => /^[–—-]$/.test(t)) ?? null,
        input: input ? { ...style(input), width: Math.round(input.getBoundingClientRect().width), backgrounds: [...new Set(cells.map((c) => c.querySelector('input')).filter(Boolean).map((i) => getComputedStyle(i).backgroundColor))] } : null,
        secondary: secondary ? { sample: text(secondary), ...style(secondary) } : null,
        hasButton: cell ? [...cell.querySelectorAll('button')].map((x) => x.getAttribute('aria-label') ?? text(x))[0] ?? null : null,
      };
    });
    let col = 0;
    const groups = groupRow ? [...groupRow.children].map((th) => { const span = Number(th.getAttribute('colspan') ?? 1); const g = { label: text(th), from: col, span, style: style(th) }; col += span; return g; }) : [];
    out.table = { label: table.getAttribute('aria-label') ?? '', groups, leaves, rowHeight: firstBody ? Math.round(firstBody.getBoundingClientRect().height) : 0, headerRows: headRows.length };
  }
  for (const el of document.querySelectorAll('button, [role="button"], input[type="search"]')) {
    if (el.closest('tbody')) continue;
    const name = el.getAttribute('aria-label') ?? text(el) ?? el.getAttribute('placeholder');
    const group = el.closest('[role="group"], [role="radiogroup"], [role="toolbar"]');
    out.controls.push({ name: el.tagName === 'INPUT' ? `search: ${el.getAttribute('placeholder') ?? name}` : name,
      pressed: el.getAttribute('aria-pressed') ?? el.getAttribute('aria-checked') ?? el.getAttribute('data-state'), popup: el.getAttribute('aria-haspopup'),
      inGroup: group?.getAttribute('aria-label') ?? null, height: Math.round(el.getBoundingClientRect().height), ...style(el) });
  }
  // decorated elements outside tables: chips, badges, bars (own background, short text)
  for (const el of document.querySelectorAll('body *')) {
    if (el.closest('table, button, input, [role="menu"]') || ['BUTTON', 'INPUT'].includes(el.tagName)) continue;
    const s = getComputedStyle(el); const t = text(el);
    if (/rgba\(0, 0, 0, 0\)/.test(s.backgroundColor) || s.backgroundColor === 'rgb(255, 255, 255)' || !t || t.length > 40) continue;
    out.decor.push({ text: t, background: s.backgroundColor, color: s.color, radius: px(s.borderTopLeftRadius), fontSize: px(s.fontSize) });
  }
  for (const el of document.querySelectorAll('body *')) {
    const s = getComputedStyle(el);
    for (const c of [s.color, s.backgroundColor, s.borderTopColor]) if (!/rgba\(0, 0, 0, 0\)/.test(c)) out.palette[c] = (out.palette[c] ?? 0) + 1;
  }
  return out;
}

// one browser per page: robust everywhere (and required by some sandboxed Chromium builds)
async function snapshot(target, shot) {
  const browser = await launch();
  try { const page = await open(browser, target); const spec = await page.evaluate(readSpec); if (shot) await page.screenshot({ path: shot, fullPage: true }); return spec; }
  finally { await browser.close(); }
}
const launch = () => chromium.launch({ executablePath: process.env.CHROMIUM_PATH || undefined, args: process.env.CHROMIUM_PATH ? ['--no-sandbox', '--single-process', '--no-zygote'] : [] });

function toMarkdown(name, spec) {
  const t = spec.table; const L = [`# Design spec — ${name}`, '', '_Generated by tools/design-spec.mjs from the rendered design. Copy labels and order EXACTLY._', ''];
  if (t) {
    L.push(`## Table "${t.label}" — ${t.headerRows} header rows, row height ${t.rowHeight}px`, '');
    if (t.groups.length) L.push('Group headers: ' + t.groups.map((g) => `${g.label ? `"${g.label}"` : '(empty)'}×${g.span}`).join(' · ') + `  — style ${g0(t.groups)}`, '');
    L.push('| # | Label | Width | Header | Body align / font | Value colors | Empty shown as | Extra |', '|---|---|---|---|---|---|---|---|');
    t.leaves.forEach((c, i) => L.push(`| ${i + 1} | "${c.label}" | ${c.width}px | ${c.header.fontSize}px/${c.header.fontWeight}${c.header.textTransform !== 'none' ? ' ' + c.header.textTransform : ''} | ${c.body ? `${c.body.textAlign} ${c.body.fontFamily} ${c.body.fontSize}px/${c.body.fontWeight} ${c.body.color}${c.body.position === 'sticky' ? ' **sticky**' : ''} nowrap=${c.body.whiteSpace === 'nowrap'}` : '—'} | ${c.conditionalColors.length ? 'CONDITIONAL: ' + c.conditionalColors.join(', ') : c.value ? c.value.color : '—'} | ${c.emptyShownAs ?? '—'} | ${[c.input && `input ${c.input.width}px ${c.input.fontSize}px r${c.input.borderRadius}`, c.secondary && `secondary "${c.secondary.sample}" ${c.secondary.fontSize}px ${c.secondary.color}`, c.hasButton && `button "${c.hasButton}"`].filter(Boolean).join('; ') || '—'} |`));
    L.push('', `Cell padding ${t.leaves[0]?.body?.paddingY}px × ${t.leaves[0]?.body?.paddingX}px · vertical lines: ${t.leaves[0]?.body?.borderRight}`, '');
  }
  L.push('## Controls (outside the table)', '', '| Name | Group | State | Popup | Font | Colors | Border/radius | Height |', '|---|---|---|---|---|---|---|---|');
  for (const c of spec.controls) L.push(`| "${c.name}" | ${c.inGroup ?? '—'} | ${c.pressed ?? '—'} | ${c.popup ?? '—'} | ${c.fontSize}px/${c.fontWeight} | ${c.color} on ${c.background} | ${c.borderRight} r${c.borderRadius} | ${c.height}px |`);
  L.push('', '## Decorated elements (chips, badges, bars)', '', ...(spec.decor ?? []).map((x) => `- "${x.text}" — ${x.background} text ${x.color} ${x.fontSize}px r${x.radius}`));
  L.push('', '## Palette (color → uses)', '', Object.entries(spec.palette).sort((x, y) => y[1] - x[1]).map(([c, n]) => `${c} ×${n}`).join(' · '), '');
  return L.join('\n');
}
const g0 = (gs) => { const s = gs.find((g) => g.label)?.style; return s ? `${s.fontSize}px/${s.fontWeight} ${s.textTransform} spacing ${s.letterSpacing}px ${s.color}` : '—'; };

// ── compare: only design properties, never data values ──
const near = (x, y, tol) => Math.abs((x ?? 0) - (y ?? 0)) <= tol;
const rgb = (c) => (c?.match(/\d+(\.\d+)?/g) ?? []).slice(0, 3).map(Number);
const sameColor = (x, y) => { const p = rgb(x), q = rgb(y); return p.length === 3 && q.length === 3 && p.every((v, i) => Math.abs(v - q[i]) <= 12); };
function diff(d, b) {
  const m = []; const add = (severity, where, what, design, build) => m.push({ severity, where, what, design, build });
  if (!d.table || !b.table) { if (d.table) add('content', 'table', 'missing', 'present', 'absent'); }
  else {
    const dl = d.table.leaves.map((c) => c.label), bl = b.table.leaves.map((c) => c.label);
    if (dl.join('|') !== bl.join('|')) add('content', 'table', 'columns (order + labels)', dl.join(' · '), bl.join(' · '));
    const dg = d.table.groups.map((g) => `${g.label}×${g.span}`).join(' · '), bg = b.table.groups.map((g) => `${g.label}×${g.span}`).join(' · ');
    if (dg !== bg) add('content', 'table', 'group headers', dg, bg);
    if (!near(d.table.rowHeight, b.table.rowHeight, 4)) add('style', 'table', 'row height', `${d.table.rowHeight}px`, `${b.table.rowHeight}px`);
    for (const dc of d.table.leaves) {
      const bc = b.table.leaves.find((c) => c.label === dc.label); if (!bc) continue;
      const w = `column "${dc.label}"`;
      if (!near(dc.width, bc.width, Math.max(12, dc.width * 0.15))) add('style', w, 'width', `${dc.width}px`, `${bc.width}px`);
      for (const k of ['fontSize', 'fontWeight', 'textTransform']) if (String(dc.header[k]) !== String(bc.header[k])) add('style', w, `header ${k}`, dc.header[k], bc.header[k]);
      if (dc.body && bc.body) {
        for (const k of ['textAlign', 'whiteSpace', 'position', 'fontWeight']) if (String(dc.body[k]) !== String(bc.body[k])) add('style', w, `cell ${k}`, dc.body[k], bc.body[k]);
        if (!near(dc.body.fontSize, bc.body.fontSize, 0.5)) add('style', w, 'cell fontSize', dc.body.fontSize, bc.body.fontSize);
        if (/mono/i.test(dc.body.fontFamily) !== /mono/i.test(bc.body.fontFamily)) add('style', w, 'cell font family', dc.body.fontFamily, bc.body.fontFamily);
        if (!sameColor(dc.body.color, bc.body.color) && !dc.conditionalColors.length) add('style', w, 'cell color', dc.body.color, bc.body.color);
        if ((dc.body.borderRight === 'none') !== (bc.body.borderRight === 'none')) add('style', w, 'vertical line', dc.body.borderRight, bc.body.borderRight);
        if (!near(dc.body.paddingX, bc.body.paddingX, 2) || !near(dc.body.paddingY, bc.body.paddingY, 2)) add('style', w, 'cell padding', `${dc.body.paddingY}×${dc.body.paddingX}`, `${bc.body.paddingY}×${bc.body.paddingX}`);
      }
      if (dc.conditionalColors.length && bc.conditionalColors.length < 2) add('rule', w, 'conditional value colors', dc.conditionalColors.join(', '), bc.conditionalColors.join(', ') || 'none');
      if (dc.emptyShownAs && dc.emptyShownAs !== bc.emptyShownAs) add('rule', w, 'empty value shown as', dc.emptyShownAs, bc.emptyShownAs ?? '(not seen)');
      if (!!dc.input !== !!bc.input) add('content', w, 'editable input', !!dc.input, !!bc.input);
      if (dc.secondary && !bc.secondary) add('content', w, 'secondary text under value', dc.secondary.sample, 'missing');
      if (dc.hasButton && !bc.hasButton) add('content', w, 'button in cell', dc.hasButton, 'missing');
    }
  }
  for (const dd of d.decor ?? []) {
    const bd = (b.decor ?? []).find((x) => x.text.replace(/\d+/g, '#') === dd.text.replace(/\d+/g, '#'));
    if (!bd) { add('content', 'decorated element', `"${dd.text}"`, `${dd.background}`, 'missing'); continue; }
    if (!sameColor(dd.background, bd.background)) add('style', `"${dd.text}"`, 'background', dd.background, bd.background);
    if (!sameColor(dd.color, bd.color)) add('style', `"${dd.text}"`, 'text color', dd.color, bd.color);
  }
  if (d.table && b.table) for (const dc of d.table.leaves) {
    const bc = b.table.leaves.find((c) => c.label === dc.label);
    if (dc.input && bc?.input) { const extra = bc.input.backgrounds.filter((x) => !dc.input.backgrounds.some((y) => sameColor(x, y)));
      if (extra.length) add('rule', `column "${dc.label}"`, 'input background (state styling not in the design?)', dc.input.backgrounds.join(', '), bc.input.backgrounds.join(', ')); }
  }
  const norm = (n) => n.replace(/\s+/g, ' ').replace(/ for .*$/, '').trim().toLowerCase();
  for (const dc of d.controls) {
    const bc = b.controls.find((c) => norm(c.name) === norm(dc.name));
    if (!bc) { add('content', 'controls', `control "${dc.name}"`, 'present', 'missing'); continue; }
    const w = `control "${dc.name}"`;
    if ((dc.inGroup ?? '') !== (bc.inGroup ?? '') && dc.inGroup) add('content', w, 'grouped as', dc.inGroup, bc.inGroup ?? 'not grouped');
    if (dc.popup && !bc.popup) add('content', w, 'opens a menu', dc.popup, 'no');
    if (!near(dc.fontSize, bc.fontSize, 0.5) || dc.fontWeight !== bc.fontWeight) add('style', w, 'font', `${dc.fontSize}px/${dc.fontWeight}`, `${bc.fontSize}px/${bc.fontWeight}`);
    // rgb(0, 0, 0) on an input = the browser default (the design never set a color) → not a design decision
    if (!sameColor(dc.color, bc.color) && !(dc.name.startsWith('search:') && dc.color === 'rgb(0, 0, 0)')) add('style', w, 'text color', dc.color, bc.color);
    if (!sameColor(dc.background, bc.background)) add('style', w, 'background', dc.background, bc.background);
    if (!near(dc.height, bc.height, 4)) add('style', w, 'height', `${dc.height}px`, `${bc.height}px`);
  }
  for (const bc of b.controls) if (!d.controls.some((c) => norm(c.name) === norm(bc.name))) add('content', 'controls', `extra control "${bc.name}"`, 'absent', 'present');
  return m;
}

async function withServer(start, fn) {
  if (!start) return fn();
  const port = 5181;
  const child = spawn('npm', ['run', 'dev', '--', '--port', String(port), '--strictPort'], { env: { ...process.env, VITE_API_MODE: 'mock', VITE_API_BASE_URL: '' }, stdio: 'ignore', shell: process.platform === 'win32' });
  for (let i = 0; i < 60; i++) { try { await fetch(`http://localhost:${port}`); break; } catch { await new Promise((r) => setTimeout(r, 500)); } }
  try { return await fn(port); } finally { child.kill(); }
}

if (cmd === 'extract' && a) {
  const outDir = flag('--out', 'analysis/design-spec'); mkdirSync(outDir, { recursive: true });
  const spec = await snapshot(a);
  const name = basename(a, '.html');
  writeFileSync(`${outDir}/${name}.json`, JSON.stringify(spec, null, 2)); writeFileSync(`${outDir}/${name}.md`, toMarkdown(name, spec));
  console.log(`wrote ${outDir}/${name}.md and .json — ${spec.table ? spec.table.leaves.length + ' columns, ' : ''}${spec.controls.length} controls`);
} else if (cmd === 'compare' && a && b) {
  const outDir = `${flag('--out', 'plan/design-diff')}/${basename(a, '.html')}`; mkdirSync(outDir, { recursive: true });
  const result = await withServer(rest.includes('--start'), async (port) => {
    const url = /^https?:/.test(b) ? b : `http://localhost:${port ?? 5173}${b}`;
    const d = await snapshot(a, `${outDir}/design.png`);
    const bs = await snapshot(url, `${outDir}/build.png`);
    return diff(d, bs);
  });
  const lines = ['| Severity | Where | What | Design | Build |', '|---|---|---|---|---|', ...result.map((r) => `| ${r.severity} | ${r.where} | ${r.what} | ${r.design} | ${r.build} |`)];
  writeFileSync(`${outDir}/differences.md`, `# Design vs build — ${basename(a)}\n\nScreenshots: design.png, build.png\n\n${result.length ? lines.join('\n') : 'No differences beyond tolerance.'}\n`);
  const count = (s) => result.filter((r) => r.severity === s).length;
  console.log(`${result.length} difference(s): content ${count('content')}, rules ${count('rule')}, style ${count('style')} → ${outDir}/differences.md`);
  process.exit(result.length ? 1 : 0);
} else { console.error('usage: extract <design.html> | compare <design.html> <url|/route> [--start]'); process.exit(2); }
