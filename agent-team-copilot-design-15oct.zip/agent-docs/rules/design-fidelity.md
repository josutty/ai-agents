# Design fidelity — the screen must match the wireframe

Measured, never eyeballed (Playwright renders the HTML):
- `node tools/design-spec.mjs extract <file.html#screen-id>` → `analysis/design-spec/<file>-<screen-id>.md` (+ .json).
  `#screen-id` picks ONE screen inside a prototype that holds several (`dealer.html#login`); a one-screen file needs no id.
  It records: exact labels and order, table columns/groups/widths, controls with grouping and state, chips and bars,
  the page background, the main card/panel, every text's placement (inside/outside the card, left/center/right, which
  text shares its line), input styling, fonts, colors and the palette.
- `node tools/design-spec.mjs compare <file.html#screen-id> <route> --start` → `plan/design-diff/<file>-<screen-id>/`:
  design.png, build.png, differences.md. Data values are never compared as content.

## Severities
| Severity | Examples | Effect |
|---|---|---|
| content | a label, column, control, field or cell button missing / extra / renamed | blocks |
| rule | a display rule missing, or state styling the design doesn't have | blocks |
| layout | page background, card missing or not centered, a text outside/inside the card, alignment, two texts no longer on one line | blocks |
| style | font size/weight, color, padding, radius, height, width | one-line reason in plan/history, else P1 |
| data | sample values with digits (dates, counts) present in one and not the other | information only |

## Rules
1. **Content is copied, not interpreted** — labels, order, group headers, button texts, placeholders, exactly.
   A TASK that disagrees with the spec → BLOCKED-DESIGN.
2. **Every measured value maps to a token or a Tailwind step**; nearest step within 1px, otherwise styling-engineer
   adds a token. Never hex, never `style=`.
3. **Colors come only from tokens; tokens come from the spec's Palette** (page background included).
4. **Display rules are rules** (conditional colors, "–" for empty, formats) → `analysis/display-rules.md`; unclear →
   Gate 1 question. **Never invent a rule** and **never hard-code the design's sample data** (e.g. a cycle banner
   text) as a fallback — show the API's value, or the error state.
5. **Accessibility beats the design only for contrast** — report the deviation (CONCERNS) with both values.
6. **Pages are compared after their route exists** — the coder wires the route inside the page TASK.
7. **Done** = 0 blocking differences; every style difference has its one-line reason.

Tolerances: font ±0.5px · padding ±2px · heights ±4px · widths ±15% · colors ±12 per RGB channel · texts on one line ±4px.
Not compared — check by eye at Gate 3: exact vertical spacing between blocks, icons/images, hover/focus states, animation.
