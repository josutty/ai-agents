// Senior-developer workflow: bookkeeping, context packs and checks with ZERO model tokens.
//   node tools/task.mjs status
//   node tools/task.mjs start TASK-005        record start-sha, mark in-progress (refuses on main / dirty tree)
//   node tools/task.mjs pack  TASK-005 [--role builder|tests] [--no-rules]
//   node tools/task.mjs red   TASK-005        run the task's tests: they must fail for a VALID reason (TDD proof)
//   node tools/task.mjs check TASK-005 [--design]   typecheck · eslint (task files) · steiger · related tests
//   node tools/task.mjs scope TASK-005        only the task's files changed? only approved libraries added?
//   node tools/task.mjs done  TASK-005 [--skip-design] [--no-commit] [--force]   check + scope + library → mark done → commit by path
import { appendFileSync, existsSync, mkdirSync, readFileSync, writeFileSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { basename } from 'node:path';

const [cmd, idArg, ...rest] = process.argv.slice(2);
const flag = (n) => rest.includes(n);
const opt = (n, d) => { const i = rest.indexOf(n); return i >= 0 ? rest[i + 1] : d; };
const tokens = (s) => Math.ceil(s.length / 4);
const read = (p) => readFileSync(p, 'utf8');
const sec = (ms) => `${(ms / 1000).toFixed(1)}s`;
const die = (m) => { console.error(`✘ ${m}`); process.exit(1); };
const q = (p) => `"${p}"`;

function sh(command) {
  const t = Date.now();
  const r = spawnSync(command, { shell: true, encoding: 'utf8', maxBuffer: 64 * 1024 * 1024 });
  return { code: r.status ?? 1, out: `${r.stdout ?? ''}${r.stderr ?? ''}`.replace(new RegExp(`${String.fromCharCode(27)}\\[[0-9;]*m`, 'g'), ''), ms: Date.now() - t };
}
const git = (...a) => { const r = spawnSync('git', a, { encoding: 'utf8' }); return { code: r.status ?? 1, out: (r.stdout ?? '').trim() }; };

/** Keep only what a person (or a model) needs to fix a failure. */
function compact(out, max = 30) {
  const lines = out.split('\n').map((l) => l.trimEnd()).filter((l) => l.trim() && !/node_modules/.test(l) && !/^\s*(stderr|stdout) \|/.test(l)); // library stack frames and other tests' console output are noise
  const key = lines.filter((l) => /(error|fail|✗|×|expected|received|cannot|not found|TS\d{4}|forbidden|unresolved)/i.test(l) || /\.(tsx?|jsx?|css):\d+/.test(l));
  const pick = (key.length ? key : lines.slice(-15)).map((l) => (l.length > 220 ? `${l.slice(0, 217)}…` : l));
  return pick.length > max ? [...pick.slice(0, max), `… +${pick.length - max} more line(s) — run the command to see all`] : pick;
}

// Generated output stays out of git (local-only ignore, no tracked change): packs and design screenshots.
function ensureExcludes() {
  try { const ex = exists('.git/info/exclude') ? read('.git/info/exclude') : ''; const add = ['plan/packs/', 'plan/design-diff/*/*.png'].filter((x) => !ex.includes(x)); if (add.length) appendFileSync('.git/info/exclude', `\n${add.join('\n')}\n`); } catch { /* not fatal */ }
}

// ── parsing ──
const cells = (line) => line.split('|').slice(1, -1).map((c) => c.trim());
function parseTask(id) {
  if (!/^(TASK|BUG)-\d+$/.test(id ?? '')) die('give a task id, e.g. TASK-005');
  const file = `plan/tasks/${id}.md`;
  if (!existsSync(file)) die(`${file} not found`);
  const text = read(file);
  const fm = Object.fromEntries((text.match(/^---\n([\s\S]*?)\n---/)?.[1] ?? '').split('\n').map((l) => l.match(/^([\w-]+):\s*([^#]*)/)).filter(Boolean).map((m) => [m[1], m[2].trim()]));
  const sections = {}; let cur = '';
  for (const line of text.split('\n')) { const h = line.match(/^## (.+)/); if (h) { cur = h[1].trim(); sections[cur] = []; } else if (cur) sections[cur].push(line); }
  const body = (name) => (sections[name] ?? []).join('\n');
  const files = (sections.Files ?? []).filter((l) => l.startsWith('|')).map(cells).filter((c) => c[0] && !/^(Path|-+)$/i.test(c[0].replace(/[`:-]/g, '')) && !/^-+$/.test(c[0]))
    .map((c) => ({ path: c[0].replace(/`/g, ''), kind: c[1] ?? '', owner: c[2] ?? '', mode: (c[3] ?? '').toLowerCase() }));
  const design = body('Design');
  return { id, file, text, fm, files, title: text.match(/^# .+/m)?.[0].replace(/^#\s*/, '') ?? id, depends: (fm['depends-on'] ?? '').match(/(TASK|BUG)-\d+/g) ?? [],
    components: [...text.matchAll(/^### (\w+)/gm)].map((m) => m[1]), source: design.match(/Source:\s*(\S+)/)?.[1], spec: design.match(/Spec:\s*(\S+)/)?.[1],
    route: design.match(/Route:\s*(\/\S*)/)?.[1], templates: [...text.matchAll(/Template:\s*`?(agent-docs\/templates\/[\w.-]+)`?/g)].map((m) => m[1]),
    isPage: false, sections };
}
const withPage = (t) => ({ ...t, isPage: t.files.some((f) => f.path.startsWith('src/pages/')) });
const loadTask = (id) => withPage(parseTask(id));
const exists = (p) => existsSync(p);

function progress() {
  if (!exists('plan/PROGRESS.md')) die('plan/PROGRESS.md not found — run the architect first');
  return read('plan/PROGRESS.md').split('\n').filter((l) => /^\|\s*(TASK|BUG)-\d+\s*\|/.test(l)).map((l) => { const c = cells(l); return { id: c[0], slice: c[1], goal: c[2], depends: c[3] ?? '', status: c[c.length - 1] }; });
}
function setStatus(id, status) {
  const p = 'plan/PROGRESS.md';
  writeFileSync(p, read(p).split('\n').map((l) => { if (!new RegExp(`^\\|\\s*${id}\\s*\\|`).test(l)) return l; const c = cells(l); c[c.length - 1] = status; return `| ${c.join(' | ')} |`; }).join('\n'));
  const f = `plan/tasks/${id}.md`;
  if (exists(f)) writeFileSync(f, read(f).replace(/^status:.*$/m, `status: ${status}`));
}
const historyFile = (id) => `plan/history/${id}.md`;
const startInfo = (id) => { const t = exists(historyFile(id)) ? read(historyFile(id)) : ''; return { sha: t.match(/^start-sha:\s*(\w+)/m)?.[1], started: t.match(/^started:\s*(\S+)/m)?.[1], red: /RED evidence/.test(t) }; };

// ── commands ──
function status() {
  const rows = progress(); const done = new Set(rows.filter((r) => r.status === 'done').map((r) => r.id));
  const count = (s) => rows.filter((r) => r.status === s).length;
  const show = rows.length > 40 ? rows.filter((r) => r.status !== 'done') : rows;
  console.log('| Task | Slice | Goal | Status |\n|---|---|---|---|');
  for (const r of show) console.log(`| ${r.id} | ${r.slice} | ${r.goal.slice(0, 50)} | ${r.status} |`);
  const ready = rows.filter((r) => r.status === 'open' && (r.depends.match(/(TASK|BUG)-\d+/g) ?? []).every((d) => done.has(d)));
  console.log(`\n${count('done')} done · ${count('in-progress')} in progress · ${count('open')} open${rows.length > 40 ? ` (${count('done')} done rows hidden)` : ''}`);
  console.log(ready.length ? `Ready next: ${ready.slice(0, 6).map((r) => r.id).join(', ')}` : 'Ready next: none (everything open is waiting on a dependency)');
}

function start(id) {
  const t = loadTask(id);
  if (git('rev-parse', '--is-inside-work-tree').code) die('not a git repository');
  const branch = git('branch', '--show-current').out;
  const base = exists('PROJECT.md') ? read('PROJECT.md').match(/^base-branch:\s*(\S+)/m)?.[1] : undefined;
  if (['main', 'master', 'develop', base].includes(branch)) die(`you are on "${branch}" — work on a feat/ or fix/ branch (git checkout -b feat/<name>)`);
  const dirty = git('status', '--porcelain').out.split('\n').filter(Boolean);
  if (dirty.length && !flag('--force')) die(`working tree not clean (${dirty.length} change(s): ${dirty.slice(0, 5).map((l) => l.slice(3)).join(', ')}) — commit or stash first, or use --force`);
  const done = new Set(progress().filter((r) => r.status === 'done').map((r) => r.id));
  const waiting = t.depends.filter((d) => !done.has(d));
  if (waiting.length) console.log(`⚠️  depends on ${waiting.join(', ')} — not done yet`);
  mkdirSync('plan/history', { recursive: true });
  const info = startInfo(id);
  if (!info.sha) appendFileSync(historyFile(id), `${exists(historyFile(id)) ? '\n' : ''}start-sha: ${git('rev-parse', 'HEAD').out}\nstarted: ${new Date().toISOString()}\n`);
  setStatus(id, 'in-progress');
  console.log(`✔ ${id} started on ${branch} · start-sha ${(info.sha ?? git('rev-parse', 'HEAD').out).slice(0, 8)}`);
  console.log(`  ${t.title}\n  next: node tools/task.mjs pack ${id}${t.fm.tests === 'first' ? ' --role tests   (tests first)' : ''}`);
}

const fence = (path, body) => `### ${path}\n\`\`\`${path.split('.').pop()}\n${body}\n\`\`\``;
function tableRows(path, needles) {
  if (!exists(path)) return null;
  const lines = read(path).split('\n'); const table = lines.filter((l) => l.startsWith('|'));
  if (table.length <= 14) return needles.some((n) => n && lines.join('\n').toLowerCase().includes(n.toLowerCase())) ? lines.join('\n').trim() : null; // small file: only if it mentions this task
  const head = table.slice(0, 2); const hits = table.slice(2).filter((l) => needles.some((n) => n && l.toLowerCase().includes(n.toLowerCase())));
  return hits.length ? [...head, ...hits].join('\n') : null;
}
function pack(id) {
  const t = loadTask(id); const role = opt('--role', 'builder');
  if (!['builder', 'tests'].includes(role)) die('--role is builder or tests');
  const parts = []; const add = (title, text) => { if (text) parts.push({ title, text: `## ${title}\n\n${text.trim()}\n` }); };
  const slices = [...new Set(t.files.map((f) => f.path.match(/^src\/(\w+)\/([\w-]+)/)).filter(Boolean).map((m) => `${m[1]}/${m[2]}`))];
  const needles = [...t.components, ...slices];

  add('The task', t.text.replace(/^---[\s\S]*?---\n/, '').trim());
  if (role === 'builder') {
    add('Design spec (measured — copy labels exactly)', t.spec && exists(t.spec) ? read(t.spec).replace(/^# .*\n+/, '') : (t.spec ? `(${t.spec} not found — run: node tools/design-spec.mjs extract ${t.source ?? '<screen>'})` : ''));
    add('Display rules', tableRows('analysis/display-rules.md', needles));
    add('Library decisions', tableRows('plan/library-decisions.md', needles));
    add('API used here', tableRows('plan/api-integration-points.md', slices));
  }
  const isTest = (f) => /test|spec/i.test(`${f.owner} ${f.kind}`);
  // builder: files to edit + the tests to satisfy · tests: test files to edit + code that already exists (tests-after tasks)
  const include = t.files.filter((f) => exists(f.path) && (role === 'builder' ? f.mode.startsWith('edit') || isTest(f) : isTest(f) ? f.mode.startsWith('edit') : f.mode.startsWith('new')));
  add('Existing files you need', include.map((f) => { const ls = read(f.path).split('\n'); return fence(f.path, ls.length > 220 ? `${ls.slice(0, 220).join('\n')}\n// … ${ls.length - 220} more lines — open the file if you need them` : ls.join('\n')); }).join('\n\n'));
  const own = new Set(t.files.map((f) => f.path));
  const refs = new Set(); for (const m of t.text.matchAll(/(?:@|\b)(entities|features|widgets|shared|pages)\/([\w-]+)(?:\/([\w-]+))?/g)) refs.add(m[1] === 'shared' ? `src/shared/${m[2]}/index.ts` : `src/${m[1]}/${m[2]}/index.ts`);
  const apis = [...refs].filter((p) => exists(p) && !own.has(p)).slice(0, 8);
  add('Public APIs you may import (signatures)', apis.map((p) => fence(p, read(p).split('\n').slice(0, 60).join('\n'))).join('\n\n'));
  if (!flag('--no-rules')) {
    const docs = role === 'builder' ? ['agent-docs/rules/styling.md', 'agent-docs/rules/ui-conventions.md', 'agent-docs/rules/design-fidelity.md'] : ['agent-docs/rules/testing.md', 'agent-docs/rules/capability-tests.md'];
    // only the AGENTS.md sections this role needs (stack, FSD, data, sensitive data, logging) — not git/gates/HANDOFF
    const want = role === 'builder' ? [1, 2, 3, 8, 9] : [1, 2, 3, 8];
    const core = exists('AGENTS.md') ? read('AGENTS.md').split(/^(?=## )/m).filter((x) => want.includes(Number(x.match(/^## (\d+)\./)?.[1]))).join('\n').trim() : '';
    add('Rules', [core, ...docs.filter(exists).map(read)].filter(Boolean).join('\n\n---\n\n'));
  }
  const tpls = role === 'tests' ? ['agent-docs/templates/test-engineer.md'] : t.templates;
  add('Templates', tpls.filter(exists).map((p) => `### ${p}\n\n${read(p).replace(/^# .*\n+/, '')}`).join('\n\n'));
  const checks = `node tools/task.mjs check ${id}${t.isPage ? ' --design' : ''}`;
  const header = `# Context pack — ${id} (${role})\n\n**Read ONLY this file** plus the files you create or edit. Do not open other plan/ or analysis/ files and do not search the repo for conventions — what you need is below.\n**Touch ONLY the files in the task's Files table.** Do not run the whole test suite, lint the whole project or build Storybook. The human runs \`${checks}\` and sends you only the failures.\n${role === 'tests' ? 'Write the tests only; they must FAIL now for a valid reason (assertion, or a `new` file that does not exist yet).\n' : 'Make the task\'s tests pass and match the design spec exactly. Never invent text, colors or behaviour the spec and display rules do not show.\n'}When finished: list the files you changed and stop.\n`;
  mkdirSync('plan/packs', { recursive: true });
  const outPath = `plan/packs/${id}.${role}.md`; const full = `${header}\n${parts.map((p) => p.text).join('\n')}`;
  writeFileSync(outPath, full);
  console.log(`✔ ${outPath} — ~${tokens(full).toLocaleString()} tokens`);
  for (const p of parts) console.log(`   ${String(tokens(p.text)).padStart(6)}  ${p.title}`);
  console.log(`   attach it to a NEW session with a plain agent and say: "Implement ${id} exactly as this pack says."`);
}

function stepList(t, { design }) {
  const exist = t.files.filter((f) => exists(f.path)).map((f) => f.path);
  const ts = exist.filter((p) => /\.(ts|tsx)$/.test(p));
  const tests = ts.filter((p) => /\.(test|spec)\.(ts|tsx)$/.test(p) && !p.startsWith('e2e/'));
  const srcOnly = ts.filter((p) => !/\.(test|spec|stories)\.(ts|tsx)$/.test(p) && !p.startsWith('e2e/'));
  const pkg = exists('package.json') ? JSON.parse(read('package.json')) : {};
  const hasSteiger = exists('steiger.config.ts') || exists('steiger.config.js') || pkg.devDependencies?.steiger;
  const steps = [{ name: 'typecheck', cmd: pkg.scripts?.typecheck ? 'npm run typecheck --silent' : 'npx tsc --noEmit' }];
  if (ts.length) steps.push({ name: 'eslint (task files)', cmd: `npx eslint ${ts.map(q).join(' ')}` });
  if (hasSteiger) steps.push({ name: 'steiger (FSD rules)', cmd: 'npx steiger ./src' });
  if (srcOnly.length || tests.length) steps.push({ name: 'tests (related)', cmd: `npx vitest related ${[...srcOnly, ...tests].map(q).join(' ')} --run --reporter=dot --passWithNoTests` });
  if (design) {
    if (t.source && t.route) steps.push({ name: 'design vs build', cmd: `node tools/design-spec.mjs compare ${q(t.source)} ${t.route} --start`, design: true });
    else console.log('⚠️  no design check: the task has no "Source:" and "Route:" in its Design section');
  }
  return steps;
}
function designLines(t) {
  const name = (() => { const [f, s] = t.source.split('#'); return `${basename(f, '.html')}${s ? `-${s}` : ''}`; })();
  const p = `plan/design-diff/${name}/differences.md`; if (!exists(p)) return [];
  return read(p).split('\n').filter((l) => /^\| (content|rule|layout) /.test(l)).slice(0, 25);
}
function check(id, { design }) {
  const t = loadTask(id); const results = []; const failures = [];
  for (const s of stepList(t, { design })) {
    const r = sh(s.cmd); const ok = r.code === 0; results.push({ ...s, ok, ms: r.ms });
    console.log(`${ok ? '✔' : '✘'} ${s.name} (${sec(r.ms)})`);
    if (!ok) { const lines = s.design ? designLines(t) : compact(r.out); const block = [`### ${s.name}`, `command: ${s.cmd}`, ...lines.map((l) => `  ${l}`)]; failures.push(block.join('\n')); console.log(lines.map((l) => `    ${l}`).join('\n')); }
  }
  mkdirSync('plan/packs', { recursive: true });
  const fp = `plan/packs/${id}.failures.md`;
  if (failures.length) { writeFileSync(fp, `# Failures for ${id}\n\nFix only these. Touch only the files in the task's Files table.\n\n${failures.join('\n\n')}\n`); console.log(`\n✘ ${failures.length} check(s) failed → send the agent plan/packs/${id}.failures.md (not the full logs)`); }
  else console.log('\n✔ all checks passed');
  return { ok: !failures.length, results };
}

function libraryCheck(sha) {
  if (!sha || !exists('package.json')) return { ok: true, added: [] };
  const old = git('show', `${sha}:package.json`); if (old.code) return { ok: true, added: [] };
  const deps = (j) => ({ ...(j.dependencies ?? {}), ...(j.devDependencies ?? {}) });
  const before = deps(JSON.parse(old.out)), after = deps(JSON.parse(read('package.json')));
  const added = Object.keys(after).filter((k) => before[k] !== after[k]);
  const approved = new Set(); const ld = 'plan/library-decisions.md';
  if (exists(ld)) for (const l of read(ld).split('\n').filter((x) => x.startsWith('|'))) { const c = cells(l); if (/^approved/i.test(c[c.length - 1] ?? '')) for (const m of (c[4] ?? '').matchAll(/(@?[\w./-]+?)@[\^~]?[\w.*-]+/g)) approved.add(m[1]); }
  const bad = added.filter((k) => !approved.has(k)); return { ok: !bad.length, added, bad };
}
function changedFiles(sha) {
  const tracked = git('diff', '--name-only', sha).out.split('\n'); const fresh = git('ls-files', '--others', '--exclude-standard').out.split('\n');
  return [...new Set([...tracked, ...fresh])].filter(Boolean).map((f) => f.replace(/\\/g, '/'));
}
function scope(id, quiet = false) {
  const t = loadTask(id); const info = startInfo(id);
  if (!info.sha) { console.log(`✘ no start-sha for ${id} — run: node tools/task.mjs start ${id}`); return { ok: false }; }
  const allowed = new Set([...t.files.map((f) => f.path), 'plan/PROGRESS.md', historyFile(id), t.file]);
  const generated = (f) => f.startsWith('plan/design-diff/'); // the design check's own report
  const changed = changedFiles(info.sha); const pkgChanged = changed.filter((f) => f === 'package.json' || f === 'package-lock.json');
  const extra = changed.filter((f) => !allowed.has(f) && !pkgChanged.includes(f) && !generated(f));
  const missing = t.files.filter((f) => f.mode.startsWith('new') && !exists(f.path)).map((f) => f.path);
  const lib = libraryCheck(info.sha);
  const ok = !extra.length && lib.ok;
  if (!quiet || !ok) {
    console.log(`${extra.length ? '✘' : '✔'} scope: ${changed.length - extra.length - pkgChanged.length} task file(s) changed${extra.length ? `, ${extra.length} OUTSIDE the Files table: ${extra.join(', ')}` : ''}`);
    console.log(`${lib.ok ? '✔' : '✘'} libraries: ${lib.added.length ? `added ${lib.added.join(', ')}${lib.ok ? ' (approved)' : ` — NOT approved in plan/library-decisions.md: ${lib.bad.join(', ')}`}` : 'no dependency changes'}`);
    if (missing.length) console.log(`⚠️  files listed as new but not created: ${missing.join(', ')}`);
  }
  return { ok, pkgChanged, lib };
}

function red(id) {
  const t = loadTask(id); const tests = t.files.map((f) => f.path).filter((p) => exists(p) && /\.(test|spec)\.(ts|tsx)$/.test(p) && !p.startsWith('e2e/'));
  if (!tests.length) die('no unit test files from the Files table exist yet — write the tests first');
  const cmd = `npx vitest run ${tests.map(q).join(' ')} --reporter=dot`; const r = sh(cmd);
  const valid = /(Failed to resolve import|Cannot find module|AssertionError|expected .* to|Unable to find|toBe\w*|toHave\w*)/.test(r.out) && !/(SyntaxError|ReferenceError|Transform failed|No test suite found|is not defined)/.test(r.out);
  let verdict; if (r.code === 0) verdict = '✘ the tests already PASS — not a valid RED (a test must fail before the code exists)';
  else if (valid) verdict = '✔ valid RED: tests fail on assertions or on files that do not exist yet'; else verdict = '✘ SUSPECT RED: the failure looks like a broken test (syntax / reference / setup), not a missing implementation';
  console.log(verdict); console.log(compact(r.out, 12).map((l) => `    ${l}`).join('\n'));
  if (!exists(historyFile(id))) mkdirSync('plan/history', { recursive: true });
  appendFileSync(historyFile(id), `RED evidence: \`${cmd}\` → ${r.code === 0 ? 'passed (invalid)' : valid ? 'valid RED' : 'suspect'}\n`);
  process.exit(r.code !== 0 && valid ? 0 : 1);
}

function done(id) {
  const t = loadTask(id); const info = startInfo(id);
  const r = check(id, { design: t.isPage && !flag('--skip-design') }); const s = scope(id);
  if (t.fm.tests === 'first' && !info.red && t.id.startsWith('TASK')) console.log(`⚠️  tests: first — no RED proof recorded (node tools/task.mjs red ${id} before building)`);
  if (!r.ok || !s.ok) { console.log(`\n✘ ${id} is NOT done — fix the items above and run done again`); process.exit(1); }
  const time = (n) => r.results.find((x) => x.name.startsWith(n)); const dur = (n) => (time(n) ? sec(time(n).ms) : 'n/a');
  const now = new Date(); const mins = info.started ? Math.round((now - new Date(info.started)) / 60000) : null;
  setStatus(id, 'done');
  writeFileSync(historyFile(id), read(historyFile(id)).replace(/\n⏱ manual[^\n]*\nDone [^\n]*\n/g, '\n')); // re-running done replaces the earlier result
  appendFileSync(historyFile(id), `\n⏱ manual${mins !== null ? ` ${mins} min` : ''} · typecheck ${dur('typecheck')} · lint ${dur('eslint')} · tests ${dur('tests')} · design ${dur('design')}\nDone ${now.toISOString()} — checks, scope and libraries passed (tools/task.mjs)\n`);
  if (flag('--no-commit')) { console.log(`\n✔ ${id} marked done (not committed)`); return; }
  const reports = changedFiles(info.sha ?? 'HEAD').filter((f) => /^plan\/design-diff\/[^/]+\/differences\.md$/.test(f));
  const paths = [...t.files.map((f) => f.path).filter((p) => exists(p) || git('ls-files', '--', p).out), 'plan/PROGRESS.md', historyFile(id), t.file, ...(s.pkgChanged ?? []), ...reports];
  const add = git('add', '--', ...paths); if (add.code) die(`git add failed: ${add.out}`);
  const c = spawnSync('git', ['commit', '-m', `${id}(manual): ${t.title.replace(/^[\w-]+:\s*/, '')}`], { encoding: 'utf8' });
  if (c.status) die(`commit failed (pre-commit hook?): ${(c.stderr || c.stdout).trim().split('\n').slice(0, 3).join(' | ')}`);
  console.log(`\n✔ ${id} done · committed ${git('rev-parse', '--short', 'HEAD').out}${mins !== null ? ` · ${mins} min` : ''}`);
  console.log('  next: node tools/task.mjs status');
}

const help = () => console.log(read(new URL(import.meta.url).pathname.replace(/^\/([A-Z]:)/, '$1')).split('\n').filter((l) => l.startsWith('//')).map((l) => l.slice(3)).join('\n'));
if (!['status', 'help', undefined].includes(cmd)) ensureExcludes();
const run = { status, start: () => start(idArg), pack: () => pack(idArg), red: () => red(idArg), check: () => { const r = check(idArg, { design: flag('--design') }); process.exit(r.ok ? 0 : 1); }, scope: () => { const s = scope(idArg); process.exit(s.ok ? 0 : 1); }, done: () => done(idArg), help };
(run[cmd] ?? help)();
