// tailwind.config.ts
import type { Config } from 'tailwindcss';
import defaultTheme from 'tailwindcss/defaultTheme';

// Every color is a CSS-variable channel triplet so opacity modifiers work (bg-primary/90).
const token = (name: string) => `rgb(var(--color-${name}) / <alpha-value>)`;

export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        surface: { DEFAULT: token('surface'), muted: token('surface-muted') },
        fg: { DEFAULT: token('fg'), muted: token('fg-muted') },
        border: { DEFAULT: token('border'), strong: token('border-strong') },
        primary: { DEFAULT: token('primary'), fg: token('primary-fg') },
        danger: { DEFAULT: token('danger'), fg: token('danger-fg') },
        success: { DEFAULT: token('success'), fg: token('success-fg') },
        warning: { DEFAULT: token('warning'), fg: token('warning-fg') },
        focus: token('focus'),
      },
      fontFamily: { sans: ['var(--font-sans)', ...defaultTheme.fontFamily.sans] },
      fontSize: {
        'heading-1': ['2rem', { lineHeight: '2.5rem', fontWeight: '700' }],
        'heading-2': ['1.5rem', { lineHeight: '2rem', fontWeight: '600' }],
        'heading-3': ['1.125rem', { lineHeight: '1.75rem', fontWeight: '600' }],
        body: ['1rem', { lineHeight: '1.5rem' }],
        'body-sm': ['0.875rem', { lineHeight: '1.25rem' }],
        caption: ['0.75rem', { lineHeight: '1rem' }],
      },
      borderRadius: { control: 'var(--radius-control)', card: 'var(--radius-card)' },
      boxShadow: { card: 'var(--shadow-card)' },
    },
  },
  plugins: [],
} satisfies Config;
