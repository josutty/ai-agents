import { productHandlers } from './product';
import { cartHandlers } from './cart';

export const allHandlers = [...productHandlers, ...cartHandlers];
export const mockOnlyHandlers = [...cartHandlers]; // x-mock: true operations only
