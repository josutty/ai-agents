import { http, HttpResponse } from 'msw';
import type { ApiErrorBody, GetProductResponse, ListProductsResponse } from '@shared/api/generated/models';
import { db } from '../db';
import { apiUrl } from '../lib';

export const productHandlers = [
  http.get<never, never, ListProductsResponse>(apiUrl('/api/products'), ({ request }) => {
    const url = new URL(request.url);
    const page = Number(url.searchParams.get('page') ?? 1);
    const size = 20;
    const data = db.products.slice((page - 1) * size, page * size);
    return HttpResponse.json({ data, total: db.products.length, page });
  }),

  http.get<{ id: string }, never, GetProductResponse | ApiErrorBody>(apiUrl('/api/products/:id'), ({ params }) => {
    const product = db.products.find((p) => p.id === params.id);
    return product
      ? HttpResponse.json(product)
      : HttpResponse.json({ code: 'NOT_FOUND', message: 'Product not found' }, { status: 404 });
  }),
];
