import { http, HttpResponse } from 'msw';
import type { AddToCartRequest, AddToCartResponse, ApiErrorBody } from '@shared/api/generated/models';
import { db } from '../db';
import { apiUrl } from '../lib';

export const cartHandlers = [
  http.post<never, AddToCartRequest, AddToCartResponse | ApiErrorBody>(apiUrl('/api/cart/items'), async ({ request }) => {
    const body = await request.json();
    if (!db.products.some((p) => p.id === body.productId)) {
      return HttpResponse.json({ code: 'UNKNOWN_PRODUCT', message: 'Product not found' }, { status: 400 });
    }
    const line = db.cart.find((l) => l.productId === body.productId);
    if (line) line.quantity += body.quantity; else db.cart.push({ ...body });
    return HttpResponse.json({ items: db.cart }, { status: 201 });
  }),
];
