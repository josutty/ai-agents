import { http, HttpResponse, delay } from 'msw';
import { apiUrl } from './lib';

export const scenarios = {
  productsServerError: [http.get(apiUrl('/api/products'), () =>
    HttpResponse.json({ code: 'INTERNAL', message: 'Something went wrong' }, { status: 500 }))],
  productsEmpty: [http.get(apiUrl('/api/products'), () => HttpResponse.json({ data: [], total: 0, page: 1 }))],
  productsNetworkError: [http.get(apiUrl('/api/products'), () => HttpResponse.error())],
  productsSlow: [http.get(apiUrl('/api/products'), async () => { await delay('infinite'); return HttpResponse.json({ data: [], total: 0, page: 1 }); })],
};
