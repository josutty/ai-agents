import { faker } from '@faker-js/faker';
import type { Product } from '@shared/api/generated/models';

export const buildProduct = (overrides: Partial<Product> = {}): Product => ({
  id: faker.string.uuid(),
  name: faker.commerce.productName(),
  price: Number(faker.commerce.price({ min: 5, max: 300, dec: 2 })),
  imageUrl: `https://picsum.photos/seed/${faker.string.alphanumeric(6)}/400/300`,
  ...overrides,
});
