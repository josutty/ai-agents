import { productFixtures } from './fixtures/product';
const clone = <T>(v: T): T => structuredClone(v);
export const db = { products: clone(productFixtures), cart: [] as { productId: string; quantity: number }[] };
export const resetDb = () => {
  db.products = clone(productFixtures);
  db.cart = [];
};
