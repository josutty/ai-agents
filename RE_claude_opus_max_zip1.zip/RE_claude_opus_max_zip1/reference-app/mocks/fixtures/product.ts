import { faker } from '@faker-js/faker';
import { buildProduct } from '../factories/product';

faker.seed(1001);
export const productFixtures = Array.from({ length: 24 }, (_, i) => buildProduct({ id: String(i + 1) }));
