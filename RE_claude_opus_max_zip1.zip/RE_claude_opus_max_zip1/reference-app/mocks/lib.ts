// mocks/lib.ts
import { env } from '@shared/config';
export const apiUrl = (path: string) => `${env.apiBaseUrl}${path}`;
export const REFERENCE_DATE = new Date('2026-01-15T10:00:00Z');

/** Typed index access for fixtures — strict lint forbids `!`, and noUncheckedIndexedAccess makes `[0]` possibly undefined. */
export const at = <T>(items: readonly T[], index: number): T => {
  const item = items[index];
  if (item === undefined) throw new Error(`fixture index ${index} out of range (${items.length} items)`);
  return item;
};
