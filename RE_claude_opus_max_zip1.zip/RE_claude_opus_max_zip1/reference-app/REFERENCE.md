# Reference app

Built from the agent templates to verify them. Node 22.22+.

    npm ci
    npm run typecheck && npm run lint && npm test && npm run build && npm run build-storybook
    node tools/check-contrast.mjs
    npx playwright install chromium && npm run e2e     # not executed during verification

`npm run coverage` enforces the thresholds and fails here on purpose: the sample only has tests
for the templates, not for every feature.
