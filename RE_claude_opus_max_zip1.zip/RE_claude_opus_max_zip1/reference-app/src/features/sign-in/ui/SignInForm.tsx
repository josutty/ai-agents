import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Button } from '@shared/ui';
import { signInSchema, type SignInValues } from '../lib/signInSchema';

export interface SignInFormProps {
  onSubmit: (values: SignInValues) => Promise<void>;
  serverError?: string;
}

export function SignInForm({ onSubmit, serverError }: SignInFormProps) {
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<SignInValues>({
    resolver: zodResolver(signInSchema),
    defaultValues: { email: '', password: '' },
  });

  return (
    <form noValidate onSubmit={(e) => void handleSubmit(onSubmit)(e)} className="flex flex-col gap-4">
      <div className="flex flex-col gap-1">
        <label htmlFor="sign-in-email" className="text-body-sm font-medium">Email</label>
        <input
          id="sign-in-email" type="email" autoComplete="email"
          aria-invalid={errors.email ? true : undefined}
          aria-describedby={errors.email ? 'sign-in-email-error' : undefined}
          className="rounded-control border border-border-strong bg-surface px-3 py-2 text-body"
          {...register('email')}
        />
        {errors.email ? <p id="sign-in-email-error" className="text-caption text-danger">{errors.email.message}</p> : null}
      </div>
      <div className="flex flex-col gap-1">
        <label htmlFor="sign-in-password" className="text-body-sm font-medium">Password</label>
        <input
          id="sign-in-password" type="password" autoComplete="current-password"
          aria-invalid={errors.password ? true : undefined}
          aria-describedby={errors.password ? 'sign-in-password-error' : undefined}
          className="rounded-control border border-border-strong bg-surface px-3 py-2 text-body"
          {...register('password')}
        />
        {errors.password ? <p id="sign-in-password-error" className="text-caption text-danger">{errors.password.message}</p> : null}
      </div>
      {serverError ? <p role="alert" className="text-body-sm text-danger">{serverError}</p> : null}
      <Button type="submit" loading={isSubmitting}>Sign in</Button>
    </form>
  );
}
