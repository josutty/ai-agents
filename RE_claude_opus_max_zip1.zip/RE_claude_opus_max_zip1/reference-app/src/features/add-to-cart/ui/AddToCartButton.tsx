// src/features/add-to-cart/ui/AddToCartButton.tsx — mutation: loading + error come from the hook
import { getErrorMessage } from '@shared/api';
import { Button } from '@shared/ui';
import { useAddToCartMutation } from '../api/cartApi';

export interface AddToCartButtonProps {
  productId: string;
  productName: string;
}

export function AddToCartButton({ productId, productName }: AddToCartButtonProps) {
  const [addToCart, { isLoading, isError, error }] = useAddToCartMutation();

  const handleClick = async () => {
    try {
      await addToCart({ productId, quantity: 1 }).unwrap();
    } catch {
      // the hook's `error` renders below — nothing else to do here
    }
  };

  return (
    <div className="flex flex-col gap-1">
      <Button onClick={() => void handleClick()} loading={isLoading} aria-label={`Add ${productName} to cart`} className="w-full">
        {isLoading ? 'Adding…' : 'Add to cart'}
      </Button>
      {isError ? <p role="alert" className="text-caption text-danger">{getErrorMessage(error)}</p> : null}
    </div>
  );
}
