import { baseApi, type AddToCartRequest, type AddToCartResponse } from '@shared/api';

export const cartApi = baseApi.injectEndpoints({
  endpoints: (build) => ({
    addToCart: build.mutation<AddToCartResponse, AddToCartRequest>({
      query: (body) => ({ url: '/api/cart/items', method: 'POST', body }),
      invalidatesTags: [{ type: 'Cart', id: 'CURRENT' }],
    }),
  }),
});

export const { useAddToCartMutation } = cartApi;
