import { createSlice, type PayloadAction } from '@reduxjs/toolkit';

export interface ProductFilters { category?: string; minPrice?: number; maxPrice?: number }
interface FilterProductsState { filters: ProductFilters; page: number }

const initialState: FilterProductsState = { filters: {}, page: 1 };

export const filterProductsSlice = createSlice({
  name: 'filterProducts',
  initialState,
  reducers: {
    filtersChanged(state, action: PayloadAction<Partial<ProductFilters>>) {
      state.filters = { ...state.filters, ...action.payload };
      state.page = 1;
    },
    filtersCleared: () => initialState,
    pageChanged(state, action: PayloadAction<number>) { state.page = action.payload; },
  },
  selectors: {
    selectFilters: (s) => s.filters,
    selectPage: (s) => s.page,
  },
});

export const { filtersChanged, filtersCleared, pageChanged } = filterProductsSlice.actions;
