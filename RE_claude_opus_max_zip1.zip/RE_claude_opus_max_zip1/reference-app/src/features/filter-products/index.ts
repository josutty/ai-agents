export { filterProductsSlice, filtersChanged, filtersCleared, pageChanged, type ProductFilters } from './model/filterProductsSlice';
export { FiltersPanel, type FiltersPanelProps } from './ui/FiltersPanel';
