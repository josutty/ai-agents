import { useAppDispatch, useAppSelector } from '@shared/lib/store';
import { Button } from '@shared/ui';
import { filterProductsSlice, filtersChanged, filtersCleared } from '../model/filterProductsSlice';

export interface FiltersPanelProps {
  disabled?: boolean;
}

export function FiltersPanel({ disabled = false }: FiltersPanelProps) {
  const dispatch = useAppDispatch();
  const filters = useAppSelector(filterProductsSlice.selectors.selectFilters);

  return (
    <fieldset disabled={disabled} className="flex flex-col gap-3 rounded-card border border-border p-4">
      <legend className="px-1 text-heading-3">Filters</legend>
      <label className="flex flex-col gap-1 text-body-sm">
        Max price
        <input
          type="number"
          min={0}
          value={filters.maxPrice ?? ''}
          onChange={(e) => dispatch(filtersChanged({ maxPrice: e.target.value === '' ? undefined : Number(e.target.value) }))}
          className="rounded-control border border-border-strong bg-surface px-3 py-2 text-body text-fg"
        />
      </label>
      <Button variant="secondary" onClick={() => dispatch(filtersCleared())}>Clear filters</Button>
    </fieldset>
  );
}
