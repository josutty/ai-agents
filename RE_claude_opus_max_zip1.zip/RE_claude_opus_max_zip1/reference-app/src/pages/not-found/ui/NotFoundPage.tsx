import { Link } from 'react-router';
import { routes } from '@shared/config';

export function NotFoundPage() {
  return (
    <main className="mx-auto max-w-xl px-4 py-16 text-center">
      <h1 className="text-heading-1">Page not found</h1>
      <Link to={routes.products} className="mt-4 inline-block text-primary underline">Back to products</Link>
    </main>
  );
}
