export function AccountPage() {
  return <main className="mx-auto max-w-xl px-4 py-8"><h1 className="text-heading-1">Account</h1></main>;
}
