import { ProductCatalog } from '@widgets/product-catalog';

export function ProductsPage() {
  return (
    <main className="mx-auto max-w-7xl px-4 py-8">
      <h1 className="mb-6 text-heading-1">Products</h1>
      <ProductCatalog />
    </main>
  );
}
