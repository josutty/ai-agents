// src/entities/session/model/sessionSlice.ts
import { createSlice, type PayloadAction } from '@reduxjs/toolkit';
import { sessionExpired } from '@shared/api';

interface SessionState { token: string | null }
const initialState: SessionState = { token: null };

export const sessionSlice = createSlice({
  name: 'session',
  initialState,
  reducers: {
    signedIn(state, action: PayloadAction<string>) { state.token = action.payload; },
    signedOut: () => initialState,
  },
  extraReducers: (builder) => {
    builder.addCase(sessionExpired, () => initialState);
  },
  selectors: {
    selectIsAuthenticated: (s) => s.token !== null,
  },
});

export const { signedIn, signedOut } = sessionSlice.actions;
