// src/entities/product/api/productApi.ts
import { baseApi, type GetProductResponse, type ListProductsParams, type ListProductsResponse } from '@shared/api';

export const productApi = baseApi.injectEndpoints({
  endpoints: (build) => ({
    listProducts: build.query<ListProductsResponse, ListProductsParams>({
      query: (params) => ({ url: '/api/products', params }),
      providesTags: (result) => [
        { type: 'Product', id: 'LIST' },
        ...(result?.data.map(({ id }) => ({ type: 'Product' as const, id })) ?? []),
      ],
    }),
    getProduct: build.query<GetProductResponse, string>({
      query: (id) => `/api/products/${id}`,
      providesTags: (_r, _e, id) => [{ type: 'Product', id }],
    }),
  }),
});

export const { useListProductsQuery, useGetProductQuery } = productApi;
