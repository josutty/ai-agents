export function ProductCardSkeleton() {
  return (
    <div aria-hidden="true" className="flex animate-pulse flex-col rounded-card border border-border bg-surface p-4">
      <div className="aspect-[4/3] w-full rounded-control bg-surface-muted" />
      <div className="mt-3 h-5 w-3/4 rounded-control bg-surface-muted" />
      <div className="mt-2 h-4 w-1/3 rounded-control bg-surface-muted" />
    </div>
  );
}
