import { describe, expect, it, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { productFixtures } from '@mocks/fixtures/product';
import { at } from '@mocks/lib';
import { ProductCard } from './ProductCard';

const product = at(productFixtures, 0);

describe('ProductCard', () => {
  it('shows the name, formatted price and an image with alt text', () => {
    render(<ProductCard product={{ ...product, price: 12.5 }} />);
    expect(screen.getByRole('heading', { name: product.name })).toBeInTheDocument();
    expect(screen.getByText('$12.50')).toBeInTheDocument();
    expect(screen.getByRole('img', { name: product.name })).toBeInTheDocument();
  });

  it('calls onOpen with the product id', async () => {
    const onOpen = vi.fn();
    const user = userEvent.setup();
    render(<ProductCard product={product} onOpen={onOpen} />);
    await user.click(screen.getByRole('button', { name: `Open ${product.name}` }));
    expect(onOpen).toHaveBeenCalledWith(product.id);
  });

  it('renders the actions slot', () => {
    render(<ProductCard product={product} actions={<button type="button">Act</button>} />);
    expect(screen.getByRole('button', { name: 'Act' })).toBeInTheDocument();
  });

  it('does not crash without handlers', async () => {
    const user = userEvent.setup();
    render(<ProductCard product={product} />);
    await user.click(screen.getByRole('button', { name: `Open ${product.name}` }));
    expect(screen.getByRole('article')).toBeInTheDocument();
  });
});
