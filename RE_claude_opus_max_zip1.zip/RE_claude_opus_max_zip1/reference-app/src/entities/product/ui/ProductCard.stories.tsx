// src/entities/product/ui/ProductCard.stories.tsx
import type { Meta, StoryObj } from '@storybook/react';
import { fn } from '@storybook/test';
import { productFixtures } from '@mocks/fixtures/product';
import { at } from '@mocks/lib';
import { Button } from '@shared/ui';
import { ProductCard } from './ProductCard';

const meta = {
  component: ProductCard,
  tags: ['autodocs'],
  args: { product: at(productFixtures, 0), onOpen: fn() },
} satisfies Meta<typeof ProductCard>;
export default meta;
type Story = StoryObj<typeof meta>;

export const Default: Story = {};
export const WithActions: Story = { args: { actions: <Button onClick={fn()}>Add to cart</Button> } };
export const LongName: Story = { args: { product: { ...at(productFixtures, 0), name: 'Extra-long product name that wraps onto several lines in the card' } } };
export const WithoutHandlers: Story = { args: { onOpen: undefined } };
