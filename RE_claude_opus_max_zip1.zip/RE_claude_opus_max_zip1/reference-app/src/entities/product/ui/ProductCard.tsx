// src/entities/product/ui/ProductCard.tsx
import type { ReactNode } from 'react';
import type { Product } from '@shared/api';
import { formatPrice } from '@shared/lib/format';

export interface ProductCardProps {
  product: Product;
  /** Slot for feature actions (e.g. <AddToCartButton/>) — entities never import features. */
  actions?: ReactNode;
  onOpen?: (productId: string) => void;
}

export function ProductCard({ product, actions, onOpen }: ProductCardProps) {
  return (
    <article className="flex h-full flex-col rounded-card border border-border bg-surface p-4 shadow-card">
      <button type="button" onClick={() => onOpen?.(product.id)} className="rounded-control" aria-label={`Open ${product.name}`}>
        <img src={product.imageUrl} alt={product.name} width={400} height={300} className="aspect-[4/3] w-full rounded-control object-cover" loading="lazy" />
      </button>
      <h3 className="mt-3 text-heading-3 text-fg">{product.name}</h3>
      <p className="mt-1 text-body text-fg-muted">{formatPrice(product.price)}</p>
      {actions ? <div className="mt-auto pt-4">{actions}</div> : null}
    </article>
  );
}
