// src/app/router.tsx — one lazy route per page in plan/fsd-structure.md
import { createBrowserRouter } from 'react-router';
import { routes } from '@shared/config';
import { RequireAuth } from './providers/RequireAuth';
import { RouteErrorFallback } from './providers/RouteErrorFallback';

export const router = createBrowserRouter([
  {
    path: routes.products,
    lazy: async () => ({ Component: (await import('@pages/products')).ProductsPage }),
    errorElement: <RouteErrorFallback />,
  },
  {
    element: <RequireAuth />, // guarded group — only when the plan has a session entity + sign-in route
    errorElement: <RouteErrorFallback />,
    children: [
      { path: routes.account, lazy: async () => ({ Component: (await import('@pages/account')).AccountPage }) },
    ],
  },
  { path: '*', lazy: async () => ({ Component: (await import('@pages/not-found')).NotFoundPage }) },
]);
