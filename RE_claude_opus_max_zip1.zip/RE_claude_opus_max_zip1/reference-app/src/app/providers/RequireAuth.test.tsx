import { describe, expect, it } from 'vitest';
import { render, screen } from '@testing-library/react';
import { Provider } from 'react-redux';
import { createMemoryRouter, RouterProvider } from 'react-router';
import { makeStore } from '@app/store';
import { signedIn } from '@entities/session';
import { RequireAuth } from './RequireAuth';

const setup = (authenticated: boolean) => {
  const store = makeStore();
  if (authenticated) store.dispatch(signedIn('token-1'));
  const router = createMemoryRouter([
    { path: '/sign-in', element: <h1>Sign in</h1> },
    { element: <RequireAuth />, children: [{ path: '/account', element: <h1>Account</h1> }] },
  ], { initialEntries: ['/account'] });
  render(<Provider store={store}><RouterProvider router={router} /></Provider>);
};

describe('RequireAuth', () => {
  it('redirects anonymous users to sign-in', async () => {
    setup(false);
    expect(await screen.findByRole('heading', { name: 'Sign in' })).toBeInTheDocument();
  });
  it('renders the guarded route for a session', async () => {
    setup(true);
    expect(await screen.findByRole('heading', { name: 'Account' })).toBeInTheDocument();
  });
});
