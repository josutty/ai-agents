// src/app/providers/RequireAuth.tsx — pathless layout route (verified with a redirect test)
import { Navigate, Outlet, useLocation } from 'react-router';
import { useAppSelector } from '@shared/lib/store';
import { sessionSlice } from '@entities/session';
import { routes } from '@shared/config';

export function RequireAuth() {
  const isAuthenticated = useAppSelector(sessionSlice.selectors.selectIsAuthenticated);
  const location = useLocation();
  if (!isAuthenticated) return <Navigate to={routes.signIn} replace state={{ from: location.pathname }} />;
  return <Outlet />;
}
