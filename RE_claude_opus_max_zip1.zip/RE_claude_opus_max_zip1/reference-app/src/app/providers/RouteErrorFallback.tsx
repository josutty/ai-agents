import { useEffect } from 'react';
import { Link, useRouteError } from 'react-router';
import { routes } from '@shared/config';
import { logger } from '@shared/lib/logger';

export function RouteErrorFallback() {
  const error = useRouteError();
  useEffect(() => { logger.error('route error', { error: String(error) }); }, [error]);
  return (
    <div role="alert" className="mx-auto max-w-xl px-4 py-16 text-center">
      <h1 className="text-heading-2 text-fg">This page failed to load</h1>
      <Link to={routes.products} className="mt-4 inline-block text-primary underline">Go back</Link>
    </div>
  );
}
