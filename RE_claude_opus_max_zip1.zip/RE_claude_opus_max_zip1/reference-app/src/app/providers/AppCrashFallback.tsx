import { useEffect } from 'react';
import type { FallbackProps } from 'react-error-boundary';
import { logger } from '@shared/lib/logger';

export function AppCrashFallback({ error }: FallbackProps) {
  useEffect(() => { logger.error('app crashed', { error: String(error) }); }, [error]);
  return (
    <div role="alert" className="mx-auto max-w-xl px-4 py-16 text-center">
      <h1 className="text-heading-2 text-fg">Something went wrong</h1>
      <button type="button" onClick={() => window.location.reload()} className="mt-4 rounded-control bg-primary px-4 py-2 text-primary-fg">Reload</button>
    </div>
  );
}
