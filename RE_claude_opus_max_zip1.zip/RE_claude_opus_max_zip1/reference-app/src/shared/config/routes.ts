export const routes = {
  products: '/',
  signIn: '/sign-in',
  account: '/account',
} as const;
