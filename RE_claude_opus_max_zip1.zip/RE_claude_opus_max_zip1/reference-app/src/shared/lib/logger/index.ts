type Meta = Record<string, unknown>;
const isProd = import.meta.env.PROD;
export const logger = {
  debug: (message: string, meta?: Meta) => { if (!isProd) console.debug(message, meta); },
  info: (message: string, meta?: Meta) => { if (!isProd) console.info(message, meta); },
  warn: (message: string, meta?: Meta) => console.warn(message, meta),
  error: (message: string, meta?: Meta) => console.error(message, meta),
};
