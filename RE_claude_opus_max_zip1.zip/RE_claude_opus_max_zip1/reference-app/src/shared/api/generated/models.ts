// src/shared/api/generated/models.ts — aliases over generated schema.d.ts. Do not add fields here.
import type { components, operations } from './schema';

type Json<T> = T extends { content: { 'application/json': infer B } } ? B : never;

// ── product ──
export type Product = components['schemas']['Product'];
export type ListProductsParams = NonNullable<operations['listProducts']['parameters']['query']>;
export type ListProductsResponse = Json<operations['listProducts']['responses']['200']>;
export type GetProductResponse = Json<operations['getProduct']['responses']['200']>;

// ── cart ──
export type AddToCartRequest = components['schemas']['AddToCartRequest'];
export type Cart = components['schemas']['Cart'];
export type AddToCartResponse = Json<operations['addToCart']['responses']['201']>;

// ── errors ──
export type ApiErrorBody = components['schemas']['ApiError'];
