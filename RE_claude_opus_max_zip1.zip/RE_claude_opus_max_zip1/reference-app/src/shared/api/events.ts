import { createAction } from '@reduxjs/toolkit';
export const sessionExpired = createAction('api/sessionExpired');
