import type { ReactNode } from 'react';

export interface EmptyStateProps {
  title: string;
  description?: string;
  action?: ReactNode;
}

export function EmptyState({ title, description, action }: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center gap-2 rounded-card border border-dashed border-border p-8 text-center">
      <p className="text-heading-3 text-fg">{title}</p>
      {description ? <p className="text-body-sm text-fg-muted">{description}</p> : null}
      {action}
    </div>
  );
}
