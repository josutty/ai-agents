# ai-agents

A 20-agent OpenCode team that builds and maintains React 19 + TypeScript + RTK Query + Tailwind
apps in Feature-Sliced Design — and follows an existing project's own conventions when it isn't FSD.

| Mode | Use for |
|---|---|
| `new-project` | build from a client FSD doc + UX HTML (+ backend OpenAPI YAML, optional) |
| `gap-fill` | something from the inputs is missing, or the backend sent a new YAML |
| `feature` | add a feature to any existing project |
| `bugfix` | diagnose → failing regression test → fix |

Start here:
- **PLAYBOOK.md** — install, copy-paste prompts for each mode, what to check at each gate
- **AGENTS.md** — conventions every agent follows (copy into each project root)
- **CHANGELOG.md** — what changed and why

Agent files required by the orchestrator: app-bootstrap, codebase-scanner, wireframe-analyzer,
hybrid-api-config, schema-parser, mock-data-generator, fsd-planner, coverage-checker, architect,
store-architect, styling-engineer, test-engineer, component-generator, coder, reviewer, debugger,
researcher, reflector, orchestrator. A missing one stops the run ("<agent> not available").
