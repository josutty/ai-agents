#!/bin/sh
# Renames "github" -> ".github" so Copilot can find the agents
[ -d github ] && mv github .github && echo "Done: .github created"
