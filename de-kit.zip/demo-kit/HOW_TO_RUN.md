# Run with GitHub Copilot (VS Code)
0. FIRST: rename the folder `github` to `.github` (run setup.bat on Windows or `sh setup.sh` on Mac/Linux, or rename manually). Copilot only reads `.github`.
1. Open an empty folder in VS Code; copy this kit's contents into it.
2. Add `spec/user-story.md` and `spec/openapi.yaml`.
3. Open Copilot Chat, switch to Agent mode.
4. Type `/new-project`. This starts the `orchestrator` agent, which calls
   analyst -> scaffolder -> api-client + ui-builder -> qa-fixer as subagents.
5. Review and approve the plan when asked (reply "approved").
6. Run `npm run dev` and open http://localhost:5173.
Alternative: pick `orchestrator` in the agent dropdown and say "Start".
Tip: dry-run once before the live demo.
