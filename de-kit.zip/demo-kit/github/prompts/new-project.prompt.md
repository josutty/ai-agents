---
agent: orchestrator
description: Start a new project. Builds the React app from spec/ via the orchestrator agent.
---
Build the new project from `spec/user-story.md` and `spec/openapi.yaml`.
Follow `.github/copilot-instructions.md`.
Delegate every stage to the specialist agents; pause for my approval after the plan.
