# Project rules (demo app)
- Stack: Vite + React + TypeScript. No UI library unless the story requires it; plain CSS is fine.
- Only use endpoints defined in `spec/openapi.yaml`. Never invent endpoints or fields.
- Base URL from `VITE_API_BASE_URL`; use a Vite dev proxy to avoid CORS.
- Mock mode (MSW) controlled by `VITE_USE_MOCKS=true`, built from the spec's examples.
- Every screen needs loading, error, and empty states.
- Keep it small and demo-ready: no auth or extras beyond `spec/user-story.md`.
- Source of truth for scope: `spec/user-story.md` and `spec/openapi.yaml`.
- Shared plan lives in `spec/plan.md` (written by the Analyst).
