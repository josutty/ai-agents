@echo off
if exist github ren github .github
echo Done: .github created
