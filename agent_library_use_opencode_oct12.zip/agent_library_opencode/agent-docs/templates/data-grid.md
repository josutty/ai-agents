# Template: data grid (TanStack Table v8)

Verified on the reference app: typecheck, ESLint (strict + jsx-a11y), Steiger, 7 grid tests, production build.
Capabilities covered: frozen column, grouped headers, editable number cells with previous value, keyboard movement
(arrows, Enter, Esc), search filter, live totals, horizontal scroll. `shared/ui/data-grid` is generic
(component-generator); the business grid with its columns lives in a widget (coder).
Adapt column definitions, labels and data fields from the TASK; keep the structure.

## 1. shared/ui/data-grid/gridKeyboard.ts

```typescript
import type { KeyboardEvent } from 'react';

const MOVES: Record<string, readonly [number, number]> = {
  ArrowUp: [-1, 0], ArrowDown: [1, 0], ArrowLeft: [0, -1], ArrowRight: [0, 1], Enter: [1, 0],
};

/** Spreadsheet-style movement between editable cells (inputs carrying data-row / data-col). */
export function handleGridKeyDown(event: KeyboardEvent<HTMLInputElement>): void {
  const target = event.currentTarget;
  if (target.dataset.row === undefined) return;
  const move = MOVES[event.key];
  if (!move) return;
  const row = Number(target.dataset.row) + move[0];
  const col = Number(target.dataset.col) + move[1];
  const next = target.closest('table')?.querySelector<HTMLInputElement>(`input[data-row="${row}"][data-col="${col}"]`);
  if (!next) return;
  event.preventDefault();
  next.focus(); // the cell being left commits on blur
  next.select();
}
```

## 2. shared/ui/data-grid/EditableNumberCell.tsx

```tsx
import { useId, useState } from 'react';
import { handleGridKeyDown } from './gridKeyboard';

export interface EditableNumberCellProps {
  value: number;
  /** Previous value shown under the input ("was 25"); omit when there is none. */
  previous?: number;
  /** Accessible name, e.g. "W1 for H HSD 20FT BSVI NGB". */
  label: string;
  row: number;
  col: number;
  onCommit: (value: number) => void;
}

export function EditableNumberCell({ value, previous, label, row, col, onCommit }: EditableNumberCellProps) {
  const [draft, setDraft] = useState(String(value));
  const [synced, setSynced] = useState(value);
  if (synced !== value) { setSynced(value); setDraft(String(value)); } // value changed from outside
  const hintId = useId();
  const changed = previous !== undefined && value !== previous;

  const commit = () => {
    const next = Number(draft);
    if (draft.trim() === '' || !Number.isInteger(next) || next < 0) { setDraft(String(value)); return; }
    if (next !== value) onCommit(next);
  };

  return (
    <div className="flex flex-col items-end gap-0.5">
      <input
        type="text"
        inputMode="numeric"
        aria-label={label}
        aria-describedby={previous !== undefined ? hintId : undefined}
        data-row={row}
        data-col={col}
        value={draft}
        onChange={(e) => setDraft(e.target.value)}
        onBlur={commit}
        onKeyDown={(e) => { if (e.key === 'Escape') setDraft(String(value)); else handleGridKeyDown(e); }}
        className={`w-14 rounded-control border px-2 py-1 text-right text-body tabular-nums ${changed ? 'border-primary bg-primary/10' : 'border-border-strong bg-surface'}`}
      />
      {previous !== undefined ? <span id={hintId} className="text-caption text-fg-muted">was {previous}</span> : null}
    </div>
  );
}
```

## 3. shared/ui/data-grid/DataGrid.tsx

```tsx
import type { ReactNode } from 'react';
import { flexRender, type Table } from '@tanstack/react-table';

export interface DataGridProps<TData> {
  /** A table instance from useReactTable (columns, pinning, filtering live with the caller). */
  table: Table<TData>;
  /** Accessible name of the grid, e.g. "Indent plan, July 2026". */
  label: string;
  toolbar?: ReactNode;
  footer?: ReactNode;
}

const pinnedHead = 'sticky left-0 z-20 bg-surface-muted border-r border-border';
const pinnedCell = 'sticky left-0 z-10 bg-surface border-r border-border';

/** Grouped headers, pinned (frozen) columns, horizontal scroll, keyboard movement between editable cells. */
export function DataGrid<TData>({ table, label, toolbar, footer }: DataGridProps<TData>) {
  return (
    <div className="flex flex-col gap-3">
      {toolbar}
      <div className="overflow-x-auto rounded-card border border-border">
        <table aria-label={label} className="w-full border-collapse text-body-sm">
          <thead className="bg-surface-muted">
            {table.getHeaderGroups().map((group) => (
              <tr key={group.id}>
                {group.headers.map((header) => (
                  <th
                    key={header.id}
                    colSpan={header.colSpan}
                    scope={header.colSpan > 1 ? 'colgroup' : 'col'}
                    className={`whitespace-nowrap border-b border-border px-3 py-2 text-left text-caption font-semibold text-fg-muted ${header.column.getIsPinned() ? pinnedHead : ''}`}
                  >
                    {header.isPlaceholder ? null : flexRender(header.column.columnDef.header, header.getContext())}
                  </th>
                ))}
              </tr>
            ))}
          </thead>
          <tbody>
            {table.getRowModel().rows.map((row) => (
              <tr key={row.id} className="border-b border-border last:border-b-0">
                {row.getVisibleCells().map((cell) => {
                  const content = flexRender(cell.column.columnDef.cell, cell.getContext());
                  return cell.column.getIsPinned() ? (
                    <th key={cell.id} scope="row" className={`whitespace-nowrap px-3 py-2 text-left font-medium text-fg ${pinnedCell}`}>{content}</th>
                  ) : (
                    <td key={cell.id} className="whitespace-nowrap px-3 py-2 text-right tabular-nums text-fg">{content}</td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {footer}
    </div>
  );
}
```

## 4. shared/ui/data-grid/index.ts

```typescript
export { DataGrid, type DataGridProps } from './DataGrid';
export { EditableNumberCell, type EditableNumberCellProps } from './EditableNumberCell';
```

## 5. widget example — widgets/indent-plan/ui/IndentPlanGrid.tsx (columns, pinning, search, totals)

```tsx
import { useMemo, useState } from 'react';
import { createColumnHelper, getCoreRowModel, getFilteredRowModel, useReactTable } from '@tanstack/react-table';
import { DataGrid, EditableNumberCell } from '@shared/ui/data-grid';

export interface IndentLine {
  id: string;
  model: string;
  pipeline: { confirmed: number; fa: number; fc: number; hotInq: number };
  offtakeL3: number;
  retailL3: number;
  lastMonthPlan: number;
  weeks: number[];          // W1..W4 entered this cycle
  previousWeeks: number[];  // shown as "was N"
}

export interface IndentPlanGridProps {
  lines: IndentLine[];
  monthLabel: string;
  onChangeWeek: (lineId: string, week: number, value: number) => void;
}

const WEEKS = ['W1', 'W2', 'W3', 'W4'] as const;
const h = createColumnHelper<IndentLine>();

export function IndentPlanGrid({ lines, monthLabel, onChangeWeek }: IndentPlanGridProps) {
  const [search, setSearch] = useState('');

  const columns = useMemo(() => [
    h.accessor('model', { id: 'model', header: 'Model' }),
    h.group({ id: 'pipeline', header: 'Pipeline', columns: [
      h.accessor((r) => r.pipeline.confirmed, { id: 'confirmed', header: 'Confirmed' }),
      h.accessor((r) => r.pipeline.fa, { id: 'fa', header: 'FA' }),
      h.accessor((r) => r.pipeline.fc, { id: 'fc', header: 'FC' }),
      h.accessor((r) => r.pipeline.hotInq, { id: 'hotInq', header: 'Hot Inq' }),
    ] }),
    h.group({ id: 'offtake', header: 'Offtake L3', columns: [h.accessor('offtakeL3', { header: 'Offtake L3' })] }),
    h.group({ id: 'retail', header: 'Retail L3', columns: [h.accessor('retailL3', { header: 'Retail L3' })] }),
    h.group({ id: 'lastCycle', header: 'Last cycle', columns: [h.accessor('lastMonthPlan', { header: 'Last mth plan' })] }),
    h.group({ id: 'indent', header: `Your indent · ${monthLabel}`, columns: WEEKS.map((w, i) => h.display({
      id: w,
      header: w,
      cell: ({ row }) => (
        <EditableNumberCell
          value={row.original.weeks[i] ?? 0}
          previous={row.original.previousWeeks[i]}
          label={`${w} for ${row.original.model}`}
          row={row.index}
          col={i}
          onCommit={(v) => onChangeWeek(row.original.id, i, v)}
        />
      ),
    })) }),
  ], [monthLabel, onChangeWeek]);

  const table = useReactTable({
    data: lines,
    columns,
    getRowId: (r) => r.id,
    getCoreRowModel: getCoreRowModel(),
    getFilteredRowModel: getFilteredRowModel(),
    state: { globalFilter: search },
    onGlobalFilterChange: setSearch,
    globalFilterFn: (row, _columnId, filter: string) => row.original.model.toLowerCase().includes(filter.toLowerCase()),
    initialState: { columnPinning: { left: ['model'] } },
  });

  const units = lines.reduce((sum, l) => sum + l.weeks.reduce((a, b) => a + b, 0), 0);
  const noEntry = lines.filter((l) => l.weeks.every((v) => v === 0)).length;
  const visible = table.getRowModel().rows.length;

  return (
    <DataGrid
      table={table}
      label={`Indent plan, ${monthLabel}`}
      toolbar={(
        <label className="flex max-w-sm flex-col gap-1 text-body-sm">
          Search code or description
          <input type="search" value={search} onChange={(e) => setSearch(e.target.value)}
            className="rounded-control border border-border-strong bg-surface px-3 py-2 text-body text-fg" />
        </label>
      )}
      footer={(
        <p role="status" className="flex flex-wrap gap-4 text-body-sm text-fg-muted">
          <span><strong className="text-fg">{visible}</strong> of {lines.length} lines</span>
          <span><strong className="text-fg">{units}</strong> units · {monthLabel}</span>
          <span><strong className="text-fg">{noEntry}</strong> with no entry</span>
        </p>
      )}
    />
  );
}
```

## 6. tests — IndentPlanGrid.test.tsx (one test per capability)

```tsx
import { useCallback, useState } from 'react';
import { describe, expect, it } from 'vitest';
import { render, screen, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { IndentPlanGrid, type IndentLine } from './IndentPlanGrid';

const seed: IndentLine[] = [
  { id: '1', model: 'H HSD 20FT BSVI NGB', pipeline: { confirmed: 3, fa: 0, fc: 0, hotInq: 0 }, offtakeL3: 84, retailL3: 35, lastMonthPlan: 95, weeks: [24, 23, 23, 25], previousWeeks: [25, 24, 23, 25] },
  { id: '2', model: 'L CBC 22FT BSVI NGB', pipeline: { confirmed: 7, fa: 0, fc: 0, hotInq: 0 }, offtakeL3: 71, retailL3: 30, lastMonthPlan: 75, weeks: [19, 18, 18, 20], previousWeeks: [20, 19, 18, 20] },
  { id: '3', model: 'M SLP 24FT BSVI NGB', pipeline: { confirmed: 7, fa: 0, fc: 0, hotInq: 0 }, offtakeL3: 38, retailL3: 16, lastMonthPlan: 40, weeks: [0, 0, 0, 0], previousWeeks: [10, 10, 9, 9] },
];

function Harness() {
  const [lines, setLines] = useState(seed);
  const onChangeWeek = useCallback((id: string, week: number, value: number) =>
    setLines((ls) => ls.map((l) => (l.id === id ? { ...l, weeks: l.weeks.map((v, i) => (i === week ? value : v)) } : l))), []);
  return <IndentPlanGrid lines={lines} monthLabel="July 2026" onChangeWeek={onChangeWeek} />;
}
const status = () => screen.getByRole('status');

describe('IndentPlanGrid', () => {
  it('renders grouped headers over their columns', () => {
    render(<Harness />);
    expect(screen.getByRole('columnheader', { name: 'Pipeline' })).toHaveAttribute('colspan', '4');
    expect(screen.getByRole('columnheader', { name: 'Your indent · July 2026' })).toHaveAttribute('colspan', '4');
    expect(screen.getByRole('columnheader', { name: 'W3' })).toBeInTheDocument();
  });

  it('freezes the model column (row headers are sticky)', () => {
    render(<Harness />);
    expect(screen.getByRole('rowheader', { name: 'H HSD 20FT BSVI NGB' })).toHaveClass('sticky', 'left-0');
  });

  it('shows the previous value and the summary', () => {
    render(<Harness />);
    expect(screen.getByRole('textbox', { name: 'W1 for H HSD 20FT BSVI NGB' })).toHaveAccessibleDescription('was 25');
    expect(status()).toHaveTextContent('3 of 3 lines');
    expect(status()).toHaveTextContent('170 units · July 2026');
    expect(status()).toHaveTextContent('1 with no entry');
  });

  it('commits an edit with Enter, updates totals and moves down a row', async () => {
    const user = userEvent.setup();
    render(<Harness />);
    const w1 = screen.getByRole('textbox', { name: 'W1 for H HSD 20FT BSVI NGB' });
    await user.clear(w1);
    await user.type(w1, '30{Enter}');
    expect(status()).toHaveTextContent('176 units');
    expect(screen.getByRole('textbox', { name: 'W1 for L CBC 22FT BSVI NGB' })).toHaveFocus();
  });

  it('moves with arrow keys and reverts with Escape', async () => {
    const user = userEvent.setup();
    render(<Harness />);
    const w1 = screen.getByRole('textbox', { name: 'W1 for H HSD 20FT BSVI NGB' });
    await user.click(w1);
    await user.keyboard('{ArrowRight}');
    expect(screen.getByRole('textbox', { name: 'W2 for H HSD 20FT BSVI NGB' })).toHaveFocus();
    const w2 = screen.getByRole('textbox', { name: 'W2 for H HSD 20FT BSVI NGB' });
    await user.clear(w2);
    await user.type(w2, '99{Escape}');
    expect(w2).toHaveValue('23');
  });

  it('rejects invalid input on blur', async () => {
    const user = userEvent.setup();
    render(<Harness />);
    const w4 = screen.getByRole('textbox', { name: 'W4 for L CBC 22FT BSVI NGB' });
    await user.clear(w4);
    await user.type(w4, 'abc');
    await user.tab();
    expect(w4).toHaveValue('20');
    expect(status()).toHaveTextContent('170 units');
  });

  it('filters rows with search', async () => {
    const user = userEvent.setup();
    render(<Harness />);
    await user.type(screen.getByRole('searchbox', { name: 'Search code or description' }), 'cbc');
    expect(status()).toHaveTextContent('1 of 3 lines');
    expect(within(screen.getByRole('table')).getAllByRole('rowheader')).toHaveLength(1);
  });
});
```

## 7. e2e recipe — frozen column

```typescript
// Capability recipe: frozen column — after scrolling the grid sideways, the first column has not moved.
import { expect, test } from '@playwright/test';

test('frozen model column stays visible while scrolling', async ({ page }) => {
  await page.goto('/indent');
  const first = page.getByRole('rowheader').first();
  const before = await first.boundingBox();
  await page.locator('table').locator('xpath=..').evaluate((el) => { el.scrollLeft = 600; });
  const after = await first.boundingBox();
  expect(after?.x).toBe(before?.x);
  await expect(first).toBeInViewport();
});
```
