# Libraries & capability detection

Which library a component uses is decided from EVIDENCE in the wireframes, never from memory:
`node tools/detect-ui-capabilities.mjs inputs/ux/**/*.html` reports every complex capability.

## Decision rules (in this order)
1. **Existing project:** PROJECT.md already lists a library for the capability → use it. Never add a second one.
2. **Detector reports a capability below** → use its library (pinned major).
3. **Everything else** (layout, cards, buttons, simple tables, native inputs, lists) → plain JSX + Tailwind tokens.
4. A library NOT in this catalog → row with Status `needs-approval`; nobody installs or imports it until the human approves it at Gate 1.
5. Libraries are installed only by app-bootstrap (Run L), only from `plan/library-decisions.md` rows marked `approved`.

## Catalog
| Capability (detector id) | Use | Install (pinned) | Plain is fine when |
|---|---|---|---|
| data-grid — frozen/sticky column or header, grouped headers, editable cells, sortable columns | TanStack Table (template: `agent-docs/templates/data-grid.md`) | `@tanstack/react-table@^8` | `simple-table`: none of those features |
| virtual-list — ≥ 200 rows/items | TanStack Virtual | `@tanstack/react-virtual@^3` | fewer than 200 |
| dialog — modal, drawer, alert dialog | Radix Dialog / AlertDialog | `radix-ui@^1` | never plain (focus trap, Esc, return focus) |
| dropdown-menu | Radix DropdownMenu | `radix-ui@^1` | never plain |
| tooltip — hover/focus hints, info icons | Radix Tooltip (Popover if it holds links/buttons) | `radix-ui@^1` | never `title=` for information users need |
| tabs | Radix Tabs | `radix-ui@^1` | — |
| select — custom-styled dropdown | Radix Select | `radix-ui@^1` | the design looks like a native select → `<select>` |
| combobox — autocomplete, searchable select | cmdk | `cmdk@^1` | — |
| date-picker — calendar UI | react-day-picker + date-fns | `react-day-picker@^9 date-fns@^4` | the design shows a plain date field → `<input type="date">` |
| chart | Recharts | `recharts@^3` | — |
| drag-drop | dnd-kit | `@dnd-kit/core@^6` | — |
| toast | Sonner | `sonner@^2` | — |
| icons | Lucide | `lucide-react@^1` | the design ships its own SVGs |

Radix and the others are headless or lightly styled: style them ONLY with the semantic Tailwind tokens so
the result matches the wireframe. Never import a library's default theme CSS.

## Tests
One test per detected feature — recipes in `agent-docs/rules/capability-tests.md`.
