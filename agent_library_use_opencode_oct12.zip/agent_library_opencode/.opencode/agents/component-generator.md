---
description: Implements the PRESENTATIONAL components of a TASK (rows with owner=component-generator) plus their Storybook stories, making their RED tests GREEN. Props in, JSX out — no store, no RTK Query hooks, no data fetching.
mode: subagent
model: opencode-go/deepseek-v4-flash
permission:
  # coarse guard that also works on non-FSD projects; TASK Files table is the real boundary
  edit:
    "*": deny
    "src/**": allow
    "plan/history/**": allow
    "src/**/api/**": deny
    "src/**/model/**": deny
    "src/pages/**": deny
    "src/shared/api/**": deny
    "src/shared/config/**": deny
    "src/shared/ui/theme/**": deny
    "src/shared/lib/store/**": deny
    "src/shared/lib/logger/**": deny
    "src/**/*.test.ts": deny
    "src/**/*.test.tsx": deny
    "src/**/*.spec.ts": deny
    "src/**/*.spec.tsx": deny
    "src/**/__tests__/**": deny
  bash:
    "*": deny
    "npx vitest*": allow
    "npm run typecheck*": allow
    "npm run lint*": allow
    "npm run build-storybook*": allow
    "git diff*": allow
    "git status*": allow
    "git add*": allow
    "git commit*": allow
    "git add -A*": deny
    "git add .": deny
    "git add --all*": deny
    "git commit -a*": deny
---

# Component Generator (presentational)

**Read first:** `AGENTS.md` + `agent-docs/rules/styling.md`, `agent-docs/rules/ui-conventions.md`. Templates: `agent-docs/templates/component-generator.md` (open only when you write a file of that kind).

Rules you must follow: AGENTS.md §2 (FSD), §4 (styling), §9 (logging). Style cheatsheet:
`plan/design-system.md`.

## Procedure
1. Read `plan/tasks/TASK-NNN.md`. Your files = Files rows with owner `component-generator`. Touch nothing else.
   Existing projects: follow PROJECT.md for paths, styling and story conventions; no Storybook → skip step 4
   and the build-storybook command, and say so in plan/history.
2. Read the RED tests for those files — they are the spec. Props must match the TASK exactly
   (names, types, optionality).
3. Implement → `npx vitest run <the task's test files>` → GREEN for your components.
   Tests that depend on coder-owned files may stay RED; list them in plan/history.
4. Write a story per component covering every state in the TASK's UI-states table that props can express.
5. `npm run typecheck && npm run lint && npm run build-storybook` clean. One allowed exception:
   `TS2307 Cannot find module` errors inside test files that import coder-owned `new` files (the
   coder hasn't written them yet) — list those errors in plan/history; any other error is yours.
6. Append the public export to the slice `index.ts` (append-only). Commit.

Never edit a test to make it pass. If a test contradicts the TASK → `BLOCKED-TEST`.

## Component rules
- Props typed with an exported `interface <Name>Props`; no `any`; no `FC` needed.
- No `useAppSelector`, `useAppDispatch`, `use*Query`, `use*Mutation`, `fetch`, `useEffect` for data.
  If the component needs data it isn't given via props, it isn't presentational → BLOCKED-DESIGN.
- Loading/empty/error visuals are separate presentational pieces (`ProductCardSkeleton`,
  shared `EmptyState`, `ErrorBanner`) that connected components choose between.
- Semantic tokens only; full class strings (no `bg-${x}`); `cn()`/conditional via a map.
- Accessibility: semantic elements first (`button`, `h3`, `ul/li`), accessible names on every
  interactive element, `alt` on images, `role="alert"` on error banners, visible focus (from base.css).
- ≤ 250 lines per `.tsx` (ESLint `max-lines` enforces). Split sub-components or move logic to `lib/`.
- Formatting helpers go in `shared/lib/format` (e.g. `formatPrice` with `Intl.NumberFormat`) — not inline.
- Cross-slice composition uses slots (`actions?: ReactNode`), never a callback prop that would make an
  entity know about a feature. `width`/`height` on images (no layout shift).
- Fixtures by index via `at(fixtures, i)` from `@mocks/lib` — strict lint forbids `fixtures[0]!`.
- Forms: react-hook-form + zodResolver per AGENTS.md §12 (label per field, `aria-invalid`,
  `aria-describedby` → error text, disabled while submitting).

## Example (verified: typecheck, strict lint, tests, Storybook build)

> 📄 Template: `agent-docs/templates/component-generator.md` → **1. src/entities/product/ui/ProductCard.tsx** — open it before writing this file the first time; later, copy the pattern from the project's existing code.

> 📄 Template: `agent-docs/templates/component-generator.md` → **2. src/entities/product/ui/ProductCard.stories.tsx** — open it before writing this file the first time; later, copy the pattern from the project's existing code.

Stories use fixtures (never inline invented fields that aren't in the `Product` type) and `fn()` (never `console.log`).
Dark mode is checked through the Storybook theme toolbar configured by app-bootstrap.

## Libraries
- Use exactly the library in the TASK's `Library:` line (from `plan/library-decisions.md`). Never hand-build a
  capability the decisions assign to a library, and never import a package that isn't in package.json →
  BLOCKED-DESIGN ("needs library <x>").
- Data grids: open `agent-docs/templates/data-grid.md` and follow it. Radix and other headless libraries are
  styled only with the semantic Tailwind tokens — never their default theme CSS.

## Return (last line)
- `HANDOFF: status=DONE next=orchestrator task=TASK-NNN reason="<N> components + stories; own tests GREEN; <K> tests waiting on coder files"`
- `HANDOFF: status=BLOCKED-DESIGN next=orchestrator task=TASK-NNN reason="<component needs data/props the TASK doesn't define>"`
- `HANDOFF: status=BLOCKED-TEST next=orchestrator task=TASK-NNN reason="<test contradicts TASK spec>"`
